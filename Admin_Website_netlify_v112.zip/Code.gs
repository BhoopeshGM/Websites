/**
 * Auto Clicker - customer request mailer  (Google Apps Script, runs under YOUR Gmail, no server needed)
 *
 * doPost : the website / extension sends a new request here -> a mail goes to ADMIN_EMAIL with all request details ("Label : value"), the payment screenshot,
 *          a PDF of the request (all details + the screenshot embedded) and two buttons:
 *            [Approve] -> opens  <your website>/?act=approve&req=<request id>
 *            [Reject]  -> opens  <your website>/?act=reject&req=<request id>
 *          The website asks you to confirm, then calls this script (action 'decide') which updates Firebase; the extension follows live.
 * Still available (not advertised in the mail): sending yourself a mail with the subject "Approve: <id>" / "Reject: <id>" is read by processReplies (every minute).
 * Result mails:  "Approved: <id>" / "Rejected: <id>" / "Failed: <id>".
 *
 * ONE-TIME SETUP: see the end of this file.
 */
var ADMIN_EMAIL   = 'bhoopeshbhoopesh74@gmail.com';        // receives the mails, and the only sender whose Approve / Reject mails are accepted
var DASHBOARD_URL = 'https://advance-auto-clicker.netlify.app';   // your hosted admin website (no trailing slash); used for the Approve / Reject buttons in the mail
var MAIL_KEY      = 'b50e3eeed5bd60215c438cac1a13eeca';   // must be the same as MAIL_KEY in the extension (auth.js) and the website (index.html)

var DB_URL  = 'https://auto-clicker-1b71f-default-rtdb.asia-southeast1.firebasedatabase.app';   // Firebase Realtime Database
var API_KEY = 'AIzaSyBRbuEBZv30NlsIhYKZ5z5obDCY51BYT5s';                                          // Firebase web API key (public, same as in index.html)
var TZ      = 'Asia/Kolkata';
var CMD_RE  = /^\s*(?:(?:re|fw|fwd)\s*:\s*)*(approve|reject)\s*:\s*\[?([A-Za-z0-9_-]{4,64})\]?\s*$/i;   // "Approve: <id>" / "Reject: <id>" (a "Re:" / "Fwd:" in front is ignored)

var SCRIPT_BUILD = 35;                                  // read by the extension + website (GET) to be sure the deployed script is new enough
var SCRIPT_VERSION = 'v96 (a payment time later than the real current time is rejected; earlier than the QR opening time is rejected) | v73 (tokens added to a running Unlimited plan are kept next to it) | v72 (a confirmed payment - real SMS or website Test Message - approves the request and sends the Payment Successful e-mail in the same call) | v71 (a request whose account change was made is never put back to pending / applied twice; a one-minute check finishes it as Approved) | v70 (a confirmed QR payment adds the tokens / expiry at once even when the customer backed out of the QR page) | v69 (messages that are not payments / tests are kept and listed under Others; every time is shown as hh:mm:ss AM/PM) | v67 (Test Message from the website is processed like a real SMS and always kept in the list with its sender; a closed QR request is erased at once) | v66b (STRICT time check: a bank message whose time is not after the QR opening time can never confirm or approve a payment, on every path; abandoned requests are erased at the end of the timer) | v66 (QR screen = pending Customer Request at once; abandoned QR requests are erased by the server when the timer runs out; every credit SMS is checked against the exact QR opening time - Payment Successful / Payment Failed + reason in MacroDroid Messages; Renew is pro-rated: days already paid are not charged again) | v65 (Payment Duration Time: a QR payment screen is tracked on the server for the whole duration even if the extension is closed or the payment is cancelled - paid inside the window = auto-approved, window over without payment = auto-rejected; every credit SMS carries its transaction date / time read from the raw body and is approved only if that time is strictly after the QR code was opened and inside the window) | v64 (every payment request is bound to its creator UID; a renewal can only change the account of the person who created the request; requests are never applied by the admin website - only this script validates them against the authoritative prices; manual approval of an unpaid / underpaid request needs an explicit admin override; a bank credit that two different customers could claim is not auto-assigned) | v63 (token balances / expiry dates change only after a confirmed payment that covers the requested tokens / expiry at the current prices, or by an admin; request values are cleaned) | v35 (Live Payment Detection runs here on a time trigger and keeps running while the website is closed; history = MacroDroid + Test messages only) | v34 (mdtest from the website keeps its entry so the website list can prove receipt, then the website removes it) | v33 (the pre-check is answered BEFORE the payment lock, so the extension can poll it continuously without slowing real payments) | v32 (extension pre-check: action mdtest stores a test entry in macrodroid_messages, reads it back and only then reports verified) | v31 (MacroDroid Messages show the customer name from the QR screen) | v28 (MacroDroid Messages keep ONLY credited SMS with a confirmed QR Payment Successful; credited-without-payment, duplicates and debited messages are not saved) | v21 (accounts are now created / renewed by the script itself as soon as a payment is confirmed (and every minute for any still pending) - no admin page has to be open; failures are written on the request as autoError; createPaidAccountsNow()) | v20 (field order Type, Customer, Notes, Date & Time ...; Notes always shown (hyphen when empty); no Payment row; green Payment Successful label without date/time; header "Customer Request - Payment Successful:") | v19 (Customer name is now the first row in both the Customer Request and the Payment Successful mails; the Payment row and the green box always show the payment date and time) | v18 (the every-minute trigger now also sends the Payment Successful mail for every confirmed payment - it no longer depends on the extension reaching this script; failures are written on the request as paymentMailError; testPaidMail()) | v17 (never mails without a stored request - no more empty "Customer Request" mails; unknown actions are refused; Payment Successful mail subject is exactly "Customer Request - Payment Successful" with only real, filled-in details; the QR match picks the live screen) | v16 (pressing Payment Completed never sends a mail: the Payment Successful mail is sent only by the final action "paidmail"; header "Customer Request - Payment Successful"; no screenshot in it; no dangling hyphens) | v15 (a confirmed payment e-mail ends with "Payment Successful" instead of the Approve / Reject buttons; the Payment Successful mail goes out as soon as the request exists) | v14 api-key (URL parameter / body field "api-key"; "key" still works) | v13-2026-10-27 (MacroDroid logging failures are no longer silent: one shared Firebase login, SA_JSON auto-repair, honest logged:true/false + logError in the response, diagnose() / ?diag=MAIL_KEY self-check) / v12-2026-10-26 (raw body kept per entry; no duplicate when Firebase retries; responses say logged:true/false) / v11 (mdl_log_ runs first in doPost/doGet; every MacroDroid POST/GET is logged to macrodroid_messages; auto-confirmed payment -> "Payment Completed" in Customer Requests + Gmail; payment SMS API; mails never fold into "Show quoted text"; buttons always -> DASHBOARD_URL = advance-auto-clicker.netlify.app)';
var MD_ = null;   // v11: the macrodroid_messages entry of THIS request (written by mdl_log_ at the very start of doPost / doGet, completed later by macLog_)
function doGet(e) {
  if (e && e.parameter && e.parameter.diag && String(e.parameter.diag) === MAIL_KEY) return json_(diagnose_());   // v13: open  <web app URL>?diag=<MAIL_KEY>  in a browser to test the Firebase connection of the DEPLOYED version
  if (e && e.parameter && Object.keys(e.parameter).length) { try { MD_ = mdl_log_(e, 'GET'); } catch (xl) { MD_ = null; } }   // v11: FIRST - every GET that carries parameters (MacroDroid test / sms GET) is logged; a bare health-check GET is not
  if (e && e.parameter && (String(e.parameter.action || '') === 'sms' || e.parameter.message || e.parameter.sms || e.parameter.key || e.parameter['api-key'])) {   // v10: a MacroDroid test / GET action is logged and handled like a POST
    var gl = LockService.getScriptLock(); try { gl.waitLock(20000); } catch (x0) {}
    try { return smsApi_(e, 'GET'); } catch (x) { return json_({ ok: false, message: String(x && x.message || x) }); }
  }
  return json_({ ok: true, service: 'request-mailer', version: SCRIPT_VERSION, build: SCRIPT_BUILD, quotaLeft: MailApp.getRemainingDailyQuota() }); }

function doPost(e) {
  try { MD_ = mdl_log_(e, 'POST'); } catch (xl) { MD_ = null; }   // v11: FIRST - before the lock and before anything can fail, the request is stored (mailer calls of the website / extension are skipped inside)
  try {                                                                                       // v33: the extension's Live Payment Detection poll never waits for / holds the payment lock
    var qq = JSON.parse((e && e.postData && e.postData.contents) || 'null');
    if (qq && qq.key === MAIL_KEY && qq.action === 'mdtest' && /^[A-Za-z0-9_-]{4,64}$/.test(String(qq.id || ''))) return mdTestApi_(qq, String(qq.id));
  } catch (xq) {}
  var lock = LockService.getScriptLock();
  try {
    try { lock.waitLock(20000); } catch (le) { if (isMacro_(e)) { macLog_('other', rawMsg_(e), 'Server busy (lock timeout) - the message was still logged, but not processed.'); return json_({ ok: false, message: 'Server busy, try again.' }); } throw le; }
    if (isMacro_(e)) return smsApi_(e, 'POST');                                                              // v10: ANY POST that is not a mailer request (JSON with MAIL_KEY) is a MacroDroid message and is always logged
    var q = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (q.key !== MAIL_KEY) return json_({ ok: false, message: 'Wrong MAIL_KEY.' });
    var id = String(q.id || ''); if (!/^[A-Za-z0-9_-]{4,64}$/.test(id)) return json_({ ok: false, message: 'Bad request id.' });
    if (q.action === 'mdtest') return mdTestApi_(q, id);                                   // v32: the extension's Live Payment Detection pre-check (store a test message, read it back)
    if (q.action === 'decide') return decideApi_(q, id);
    if (q.action === 'check') {                                                              // the customer pressed "Payment Completed": match a bank credit that arrived BEFORE the press (no mail is sent here)
      var cr = dbGet_('payment_requests/' + id);
      if (cr && cr.status === 'pending' && cr.paymentStatus !== 'successful') smsMatchRequest_(id, cr);
      try {                                                                                  // v16: only MARKS the request paid (when the payment was confirmed before the request was stored); NO e-mail is sent from here
        var ps = dbGet_('payment_status/' + id);
        if (cr && ps && ps.status === 'successful' && cr.paymentStatus !== 'successful') { var pp = Math.round((Number(ps.amount) || Number(cr.amount) || 0) * 100), pu = {}; pu['payment_requests/' + id + '/paymentStatus'] = 'successful'; pu['payment_requests/' + id + '/paidAt'] = Number(ps.at) || Date.now(); pu['payment_requests/' + id + '/paidAmount'] = pp / 100; pu['payment_requests/' + id + '/paymentMessage'] = 'Payment Completed'; db_('patch', '', pu); }
      } catch (xp) { console.error('Payment mark: ' + xp); }
      try { autoApprovePaid_(id); } catch (xa2) { console.error('Auto-create: ' + xa2); }                       // v21: payment already confirmed -> create the account now
      return json_({ ok: true, message: 'Checked.' });
    }                                   // Approve / Reject pressed on the admin website
    var props = PropertiesService.getScriptProperties();
    if (q.action === 'paidmail') {                                                           // v16: the FINAL action of a confirmed payment (the extension calls it once the request is stored and the Payment Successful animation has started) - the ONLY thing that sends the Payment Successful mail
      var pr = dbGet_('payment_requests/' + id), pst = dbGet_('payment_status/' + id);       // payment_status/<id> is written only by this script from a verified bank SMS
      if (!pr || !pst || pst.status !== 'successful') return json_({ ok: false, message: 'Payment is not confirmed (or the request is not stored) yet.' });
      var ppaise = Math.round((Number(pst.amount) || Number(pr.amount) || 0) * 100);
      if (pr.paymentStatus !== 'successful') { var pm = {}; pm['payment_requests/' + id + '/paymentStatus'] = 'successful'; pm['payment_requests/' + id + '/paidAt'] = Number(pst.at) || Date.now(); pm['payment_requests/' + id + '/paidAmount'] = ppaise / 100; pm['payment_requests/' + id + '/paymentMessage'] = 'Payment Completed'; db_('patch', '', pm); pr.paymentStatus = 'successful'; pr.paidAt = Number(pst.at) || Date.now(); }
      try { payMail_(id, pr, ppaise); } catch (xm) { console.error('Payment mail: ' + xm); }                  // v21: a mail problem must never stop the account from being created
      var apr = ''; try { apr = autoApprovePaid_(id); } catch (xa) { console.error('Auto-create: ' + xa); }   // v21: the account is created / renewed right now
      return json_({ ok: true, message: 'Payment Successful e-mail sent to ' + ADMIN_EMAIL + (apr ? ' | request: ' + apr : '') });
    }
    if (!q.force && props.getProperty('sent_' + id)) return json_({ ok: true, duplicate: true, message: 'E-mail was already sent for this request.' });
    if (q.action && q.action !== 'mail') return json_({ ok: false, message: 'Unknown action "' + String(q.action).slice(0, 30) + '" - deploy the newest Code.gs as a New version.' });   // v17: an action this script does not know must never fall through to a (blank) request mail
    var r = {}; try { r = dbGet_('payment_requests/' + id) || {}; } catch (xr) { r = {}; }              // v64: ONLY the stored request is used - details sent in the call (q.rec) are never trusted (MAIL_KEY is not a secret)
    if (!reqOk_(r)) return json_({ ok: false, message: 'Not sent: this request has no details (nothing is stored under that id).' });   // v17: never send an empty / dummy mail
    try {                                                                                    // v16: an already paid request (Resend) goes out as the Payment Successful mail (no Approve / Reject, no screenshot)
      var dbr = dbGet_('payment_requests/' + id);
      if (dbr && dbr.paymentStatus === 'successful') { if (q.force) props.deleteProperty('paid_' + id); payMail_(id, dbr, Math.round((Number(dbr.paidAmount) || Number(dbr.amount) || 0) * 100)); return json_({ ok: true, message: 'Payment Successful e-mail sent to ' + ADMIN_EMAIL }); }
    } catch (xd) { console.error('Paid check: ' + xd); }
    if (r.claim === 'waiting') return json_({ ok: false, message: 'Not sent: the e-mail is only sent after the customer presses Submit Request.' });   // v14
    var site = String(DASHBOARD_URL).replace(/\/+$/, '');   // ALWAYS the DASHBOARD_URL above - an address sent by the website / extension (q.site) is deliberately ignored
    var m = build_(id, r, site);
    var opt = { to: ADMIN_EMAIL, subject: m.subject, htmlBody: m.html, body: m.text, name: 'Auto Clicker Requests' };
    var blob = shotBlob_(r.shot, id);
    if (blob) opt.inlineImages = { shot: blob };                                              // shown inside the mail body
    // ONE attachment: a single PDF with every detail of the top section + the screenshot embedded in it
    var att = [];
    try { var pr = pdfBlob_(id, m.rows, blob, m.pdfName); att.push(pr.pdf); if (blob && !pr.imageEmbedded) att.push(blob); }   // only if the image could not go into the PDF, it is attached as a file so it is never lost
    catch (pe) { console.error('PDF not created: ' + pe); if (blob) att.push(blob); }                              // the mail is sent even if the PDF fails
    if (att.length) opt.attachments = att;
    MailApp.sendEmail(opt);
    props.setProperty('sent_' + id, String(Date.now()));
    try { smsMatchRequest_(id, r); } catch (se) { console.error('SMS match: ' + se); }                       // the SMS may have arrived BEFORE the customer pressed Request
    return json_({ ok: true, message: 'E-mail sent to ' + ADMIN_EMAIL });
  } catch (err) {
    return json_({ ok: false, message: String(err && err.message || err) });
  } finally { try { lock.releaseLock(); } catch (x) {} }
}

/** Run this once from the editor (Run > test): it asks for permission and sends a test mail. */
function test() {
  var r = { kind: 'create', status: 'pending', amount: 100, createdAt: Date.now(), customer: { name: 'Test Customer', mobile: '9999999999' }, data: { user: 'test', password: 'test123', gmail: 'x@gmail.com', tokens: 10 } };
  var m = build_('testmail1', r, DASHBOARD_URL), o = { to: ADMIN_EMAIL, subject: '[TEST ' + Utilities.formatDate(new Date(), TZ, 'HH:mm:ss') + '] ' + m.subject, htmlBody: m.html, body: m.text };
  o.attachments = [pdfBlob_('testmail1', m.rows, null, m.pdfName).pdf];                       // also asks for the Docs / Drive permission the PDF needs
  MailApp.sendEmail(o);
}

/** Run from the editor to check the SMS parser (no database needed): the log shows the amount found next to "credited", in rupees. */
function testSms() {
  ['Rs. 100.00 credited to a/c XX1234 on 26-10-26 by UPI Ref 123456. Avl Bal Rs 5,000.00', 'A/c XX1234 credited with INR 1,250.50. Avl bal INR 9999.00'].forEach(function (t) { Logger.log(smsAmount_(t) / 100 + '  <-  ' + t); });
}

/** Run this ONCE after pasting SA_JSON: checks the Firebase connection and installs the every-minute trigger that reads your Approve / Reject mails. */
function setup() {
  var ok = dbGet_('demo_config');                                   // throws a clear message if SA_JSON is missing / wrong
  ScriptApp.getProjectTriggers().forEach(function (t) { if (t.getHandlerFunction() === 'processReplies') ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('processReplies').timeBased().everyMinutes(1).create();
  ScriptApp.getProjectTriggers().forEach(function (t) { if (t.getHandlerFunction() === 'liveDetectTick') ScriptApp.deleteTrigger(t); });   // v62: Live Payment Detection is a STORED, static status - no time trigger re-checks it any more (an old one is removed here)
  GmailApp.search('in:inbox newer_than:1d', 0, 1);                  // asks for the Gmail permission
  Logger.log('OK - Firebase is reachable (demo_config = ' + JSON.stringify(ok) + ') and processReplies runs every minute.');
}

/* ===================================================================  Live Payment Detection (server side)  ===================================================================
 * v62: the status is STORED in Firebase at live_detection = { on, state, n, at (Firebase SERVER time), url } and stays exactly as stored across page refreshes / browser closings.
 * Nothing runs on a timer any more (setup() deletes the old every-minute trigger). The admin website verifies ONCE when the Web App URL in Payment SMS API is modified and stores the verdict with that URL.
 * liveDetectTick() is kept only as a manual tool: run it from the editor to re-verify and store the status for the current Web App URL. Nothing is added to macrodroid_messages by this check. */
function liveDetectTick() {
  var on = false, note = '';
  try {
    var key = dbGet_('sms_config/apiKey'), url = dbGet_('sms_config/webAppUrl') || ScriptApp.getService().getUrl();
    if (!key || !url) { note = 'no API key / web app URL'; }
    else {                                                                              // a real TEST REQUEST to the SMS endpoint (same route MacroDroid uses), then wait for it to appear in macrodroid_messages
      var id = 'lc' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
      var ep = String(url) + (String(url).indexOf('?') < 0 ? '?' : '&') + 'action=sms&key=' + encodeURIComponent(key);
      var pr = UrlFetchApp.fetch(ep, { method: 'post', contentType: 'text/plain;charset=utf-8', payload: JSON.stringify({ action: 'test', source: 'livecheck', time: id }), muteHttpExceptions: true, followRedirects: true });
      var qs = DB_URL + '/macrodroid_messages.json?orderBy=%22at%22&limitToLast=25';
      for (var i = 0; i < 6 && !on; i++) {
        var r = UrlFetchApp.fetch(qs, { headers: { Authorization: 'Bearer ' + token_() }, muteHttpExceptions: true });
        var o = {}; try { o = JSON.parse(r.getContentText()) || {}; } catch (xp) {}
        Object.keys(o).forEach(function (k) {
          var e = o[k]; if (!e || typeof e !== 'object') return;
          if (String(e.raw || '').indexOf(id) >= 0 || String(e.message || '').indexOf(id) >= 0 || e.checkId === id) { on = true; try { db_('delete', 'macrodroid_messages/' + k); } catch (xd) {} }
        });
        if (!on) Utilities.sleep(1000);
      }
      if (!on) note = 'test request (HTTP ' + pr.getResponseCode() + ') did not arrive in macrodroid_messages';
    }
  } catch (err) { on = false; note = String(err && err.message || err).slice(0, 160); }
  var n = Number(PropertiesService.getScriptProperties().getProperty('LD_N') || 0) + 1;
  try {
    var w = db_('put', 'live_detection', { on: on, state: on ? 'on' : 'off', n: n, at: { '.sv': 'timestamp' }, url: String(url || '') });
    if (w.getResponseCode() !== 200) throw new Error('HTTP ' + w.getResponseCode() + ' ' + String(w.getContentText()).slice(0, 120));
    PropertiesService.getScriptProperties().setProperty('LD_N', String(n));
  } catch (e2) { mdl_err_(e2); }
  if (note) console.log('Live Payment Detection OFF: ' + note);
  return note;
}

/* ===================================================================  Approve / Reject by e-mail  =================================================================== */

/** Time trigger (every minute). Looks for  "Approve: <id>" / "Reject: <id>"  mails sent by ADMIN_EMAIL to ADMIN_EMAIL and applies them to Firebase. */
function processReplies() {
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(25000)) return;
  try {
    try { sweepAutoApprove_(); } catch (xa) { console.error('Auto-create sweep: ' + xa); }                          // v21: FIRST - every paid request gets its account (no admin page needs to be open)
    try { sweepPayWindows_(); } catch (xw) { console.error('Payment window sweep: ' + xw); }                         // v66: an abandoned QR request (timer over / extension closed, unpaid) is erased (runs on the server, no extension needed)
    try { sweepPaidMails_(); } catch (xs) { console.error('Payment Successful sweep: ' + xs); }                    // v18: FIRST - a confirmed payment is mailed even if the extension could not reach this script
    var props = PropertiesService.getScriptProperties(), all = props.getProperties(), now = Date.now(), admin = ADMIN_EMAIL.toLowerCase();
    Object.keys(all).forEach(function (k) { if (k.indexOf('m_') === 0 && now - Number(all[k]) > 3 * 864e5) props.deleteProperty(k); });   // forget old message marks
    var threads = GmailApp.search('from:' + ADMIN_EMAIL + ' to:' + ADMIN_EMAIL + ' subject:(Approve OR Reject) newer_than:2d', 0, 30);
    threads.forEach(function (th) {
      var touched = false;
      th.getMessages().forEach(function (msg) {
        var mid = 'm_' + msg.getId(); if (props.getProperty(mid)) return;                       // every mail is handled exactly once
        var m = CMD_RE.exec(msg.getSubject() || ''); if (!m) return;
        if (String(msg.getFrom() || '').toLowerCase().indexOf(admin) < 0) return;               // only mails from the admin address
        props.setProperty(mid, String(now));                                                    // marked BEFORE the work, so a crash can never apply it twice
        var res = decide_(m[1].toLowerCase(), m[2], 'email');
        mailResult_(res);
        try { msg.markRead(); } catch (x) {}
        touched = true;
      });
      if (touched) { try { th.moveToArchive(); } catch (x) {} }
    });
  } finally { try { lock.releaseLock(); } catch (x) {} }
}


/** Website -> script:  POST { key, action:'decide', id, decision:'approve'|'reject', idToken }.  Only a signed-in ADMIN (checked with the Firebase ID token) can decide. */
function decideApi_(q, id) {
  var dec = String(q.decision || '').toLowerCase();
  if (dec !== 'approve' && dec !== 'reject') return json_({ ok: false, message: 'Bad decision (use approve or reject).' });
  try {
    token_();                                                                                  // throws "SA_JSON is not set" until the setup is done
    if (!verifyAdmin_(String(q.idToken || ''))) return json_({ ok: false, message: 'Only a signed-in admin can approve or reject.' });
  } catch (e) {
    var em = String(e && e.message || e);
    return json_({ ok: false, setup: /SA_JSON|Firebase sign-in/.test(em), message: em });
  }
  var res = decide_(dec, id, 'web', q.override === true);   // v64: q.override = the admin confirmed an unpaid / underpaid request by hand
  if (res.kind !== 'failed') mailResult_(res);                                                 // the same distinct "Approved: id" / "Rejected: id" mail
  return json_({ ok: res.kind !== 'failed', status: res.kind, needsOverride: !!res.needsOverride, setup: /SA_JSON/.test(res.note || ''), message: res.note || (res.kind === 'approved' ? 'Request approved.' : 'Request rejected.') });
}
function verifyAdmin_(idToken) {
  if (!idToken) return false;
  var r = UrlFetchApp.fetch('https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=' + API_KEY, { method: 'post', contentType: 'application/json', payload: JSON.stringify({ idToken: idToken }), muteHttpExceptions: true });
  if (r.getResponseCode() !== 200) return false;
  var u = JSON.parse(r.getContentText()).users;
  return !!(u && u[0] && dbGet_('admins/' + u[0].localId) === true);
}

/** Applies one decision. Returns { kind: 'approved' | 'rejected' | 'failed', id, rec, note }. */
/** v71: PATCH with up to 4 tries (the account change is already made when this is used). true = saved. */
function patchRetry_(path, obj) {
  for (var i = 0; i < 4; i++) {
    try { var w = db_('patch', path, obj); if (w.getResponseCode() === 200) return true; } catch (e) {}
    Utilities.sleep(300 * (i + 1));
  }
  return false;
}
/** v71: finishes requests whose account change was made but whose status is still 'pending' / 'processing' (appliedAt is the proof), and releases a request stuck in 'processing' for more than 3 minutes WITHOUT an applied account change. */
function reconcileApplied_() {
  ['processing', 'pending'].forEach(function (st) {
    var rows = {}; try { rows = dbQuery_('payment_requests', 'orderBy=' + encodeURIComponent('"status"') + '&equalTo=' + encodeURIComponent('"' + st + '"')) || {}; } catch (e) { return; }
    Object.keys(rows).forEach(function (id) {
      var r = rows[id]; if (!r || typeof r !== 'object') return;
      if (r.appliedAt) {
        var u = { status: 'approved', decidedAt: Number(r.decidedAt) || Date.now(), decidedBy: r.decidedBy || 'auto (payment confirmed)', processingAt: null, autoError: null, autoErrorAt: null };
        if (patchRetry_('payment_requests/' + id, u)) { try { PropertiesService.getScriptProperties().deleteProperty('auto_' + id); } catch (x) {} }
      } else if (st === 'processing' && Date.now() - (Number(r.processingAt) || 0) > 180000) release_(id);
    });
  });
}
function decide_(action, id, src, override) {
  var props = PropertiesService.getScriptProperties(), rec = null, claimed = false;
  try {
    if (src !== 'web' && src !== 'auto' && src !== 'timeout' && !props.getProperty('sent_' + id)) return { kind: 'failed', id: id, rec: null, note: 'Unknown request ID - no request e-mail was ever sent for it. Nothing was changed.' };
    rec = dbGet_('payment_requests/' + id);
    if (!rec) return { kind: 'failed', id: id, rec: null, note: 'This request no longer exists in Firebase. Nothing was changed.' };
    var st = String(rec.status || '');
    if (st !== 'pending') return { kind: 'failed', id: id, rec: rec, note: st === 'processing' ? 'This request is being processed right now (website / extension). Nothing was changed - check it in the Account Center.' : 'This request was already ' + st.toUpperCase() + '. Nothing was changed.' };
    if (action === 'approve' && src !== 'auto') {                                                              // v64: a manual approve is checked against the authoritative prices too; only an explicit admin override may approve an unpaid / underpaid request
      var ps0 = null; try { ps0 = dbGet_('payment_status/' + id); } catch (xp0) {}
      var tp0 = (ps0 && ps0.status === 'successful') ? timeProblem_(id, ps0) : ''; if (tp0) return { kind: 'failed', id: id, rec: rec, note: tp0 + '. This cannot be overridden.' };   // v66b
      var why = (ps0 && ps0.status === 'successful') ? (verifyPaid_(rec, ps0) || ownerProblem_(rec, ps0)) : 'There is no confirmed payment for this request (no matching bank credit).';
      if (why && !override) return { kind: 'failed', id: id, rec: rec, needsOverride: true, note: why + ' Approve it with the override option only after you have checked the payment yourself.' };
    }
    if (!claim_(id)) return { kind: 'failed', id: id, rec: rec, note: 'This request was just decided somewhere else (website / extension). Nothing was changed.' };
    claimed = true;
    var note = '', applied = false;
    if (action === 'approve') { note = rec.kind === 'renew' ? applyRenew_(rec.data || {}, rec) : applyCreate_(rec.data || {}); applied = true; }
    if (applied) { claimed = false; patchRetry_('payment_requests/' + id, { appliedAt: Date.now() }); }                  // v71: the account change is DONE - from here on this request can never be released / applied a second time (a failure below used to put it back to 'pending' although the tokens were already added)
    var done = { status: action === 'approve' ? 'approved' : 'rejected', decidedAt: Date.now(), decidedBy: src === 'web' ? 'web' : (src === 'auto' ? 'auto (payment confirmed)' : (src === 'timeout' ? 'auto (payment time expired)' : 'email')), processingAt: null };
    if (src === 'timeout') done.autoNote = 'Payment Duration Time expired - no confirmed payment arrived inside the window.';   // v65
    if (!patchRetry_('payment_requests/' + id, done)) {
      if (applied) return { kind: 'approved', id: id, rec: rec, note: note + ' (the status will be saved by the next one-minute check)' };   // appliedAt is stored: reconcileApplied_ finishes it
      throw new Error('The request status could not be saved. Check the request in the Account Center.');
    }
    claimed = false;
    return { kind: action === 'approve' ? 'approved' : 'rejected', id: id, rec: rec, note: note };
  } catch (err) {
    if (claimed) release_(id);                                                               // back to "pending": you can press Approve / Reject again
    return { kind: 'failed', id: id, rec: rec, note: String(err && err.message || err) + (claimed ? '  The request is still PENDING.' : '') };
  }
}

/** The result mail: a different subject for every outcome  ->  "Approved: id" / "Rejected: id" / "Failed: id". */
function mailResult_(res) {
  var rec = res.rec || {}, c = rec.customer || {}, d = rec.data || {};
  var head = { approved: ['Approved', '#2e7d32', 'Request approved'], rejected: ['Rejected', '#c62828', 'Request rejected'], failed: ['Failed', '#b26a00', 'Nothing was applied'] }[res.kind];
  var rows = [];
  if (rec.kind) rows.push(['Type', rec.kind === 'renew' ? 'Renewal Account' : 'Create Account'], ['Customer', [c.name, c.mobile].filter(Boolean).join(' / ') || '-'], ['Amount', rs_(rec.amount)], ['Details', details_(rec)]);
  if (res.note) rows.push([res.kind === 'failed' ? 'Reason' : 'Note', res.note]);
  var html = '<div style="font-family:Segoe UI,Arial,sans-serif;max-width:560px;margin:auto;padding:18px;background:#fff;border:1px solid #e3e3e3;border-radius:12px"><h2 style="margin:0 0 12px;color:' + head[1] + '">' + head[2] + '</h2><table style="border-collapse:collapse;font-size:14px;width:100%">' + colonRows_(rows) + '</table>' +
    '<div style="color:#999;font-size:11px;margin-top:14px">' + (res.kind === 'failed' ? 'To try again use the Approve / Reject button of the original request mail.' : 'Firebase is updated; the extension and the website show it at once.') + '</div>' + uniqueFoot_(res.id) + '</div>';
  var text = colonText_(rows) + '\n' + uniqueFootText_(res.id);
  try { MailApp.sendEmail({ to: ADMIN_EMAIL, subject: head[0] + ': ' + res.id, htmlBody: html, body: text, name: 'Auto Clicker Requests' }); } catch (e) {}
}

/* ----- Firebase REST helpers (a service account: it bypasses the database rules, so keep SA_JSON private) ----- */
/** v13: reads SA_JSON and repairs the usual paste problems (extra spaces, wrapping quotes, \\n written as text inside private_key). One reader for BOTH Firebase helpers. */
function sa_() {
  var raw = PropertiesService.getScriptProperties().getProperty('SA_JSON');
  if (!raw) throw new Error('SA_JSON is not set (Project Settings > Script Properties). See the setup notes at the end of Code.gs.');
  var sa; raw = String(raw).replace(/^\s+|\s+$/g, '');
  try { sa = JSON.parse(raw); if (typeof sa === 'string') sa = JSON.parse(sa); } catch (pe) { throw new Error('SA_JSON is not valid JSON - paste the WHOLE content of the .json file you downloaded from Firebase (' + pe.message + ').'); }
  if (!sa || !sa.client_email || !sa.private_key) throw new Error('SA_JSON has no client_email / private_key - it is not a Firebase service-account key file.');
  sa.private_key = String(sa.private_key).replace(/\\n/g, '\n');
  return sa;
}
function token_() {
  var cache = CacheService.getScriptCache(), t = cache.get('fb_token'); if (t) return t;
  var sa = sa_(), now = Math.floor(Date.now() / 1000);
  var head = b64u_(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  var claim = b64u_(JSON.stringify({ iss: sa.client_email, scope: 'https://www.googleapis.com/auth/firebase.database https://www.googleapis.com/auth/userinfo.email', aud: 'https://oauth2.googleapis.com/token', iat: now, exp: now + 3600 }));
  var sig = Utilities.base64EncodeWebSafe(Utilities.computeRsaSha256Signature(head + '.' + claim, sa.private_key)).replace(/=+$/, '');
  var r = UrlFetchApp.fetch('https://oauth2.googleapis.com/token', { method: 'post', payload: { grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: head + '.' + claim + '.' + sig }, muteHttpExceptions: true });
  var j = JSON.parse(r.getContentText());
  if (!j.access_token) throw new Error('Firebase sign-in failed: ' + (j.error_description || j.error || r.getResponseCode()));
  cache.put('fb_token', j.access_token, 3000);
  return j.access_token;
}
function b64u_(s) { return Utilities.base64EncodeWebSafe(s, Utilities.Charset.UTF_8).replace(/=+$/, ''); }
function dbPath_(p) { return String(p).split('/').map(encodeURIComponent).join('/'); }
function db_(method, path, body, extra) {
  var go = function () {
    var h = { Authorization: 'Bearer ' + token_() };
    if (extra) for (var k in extra) h[k] = extra[k];
    var opt = { method: method, headers: h, muteHttpExceptions: true };
    if (body !== undefined) { opt.contentType = 'application/json'; opt.payload = JSON.stringify(body); }
    return UrlFetchApp.fetch(DB_URL + '/' + (path ? dbPath_(path) : '') + '.json', opt);
  };
  var r = go();
  if (r.getResponseCode() === 401) { CacheService.getScriptCache().remove('fb_token'); r = go(); }   // v13: a stale cached token is replaced once, then retried
  return r;
}
function dbGet_(path) {
  var r = db_('get', path);
  if (r.getResponseCode() !== 200) throw new Error('Database read failed (' + r.getResponseCode() + '): ' + String(r.getContentText()).slice(0, 200));
  return JSON.parse(r.getContentText());
}
function hdr_(res, name) { var h = res.getHeaders(); for (var k in h) if (k.toLowerCase() === name) return h[k]; return null; }

/** pending -> processing, atomically (ETag compare-and-set): if the website / extension decides at the same moment only ONE of them wins. */
function claim_(id) {
  var p = 'payment_requests/' + id + '/status', g = db_('get', p, undefined, { 'X-Firebase-ETag': 'true' });
  if (g.getResponseCode() !== 200 || JSON.parse(g.getContentText()) !== 'pending') return false;
  return db_('put', p, 'processing', { 'if-match': hdr_(g, 'etag') }).getResponseCode() === 200;
}
function release_(id) {
  try {
    var p = 'payment_requests/' + id + '/status', g = db_('get', p, undefined, { 'X-Firebase-ETag': 'true' });
    if (JSON.parse(g.getContentText()) === 'processing') { db_('put', p, 'pending', { 'if-match': hdr_(g, 'etag') }); db_('patch', 'payment_requests/' + id, { processingAt: null }); }
  } catch (e) {}
}

/* ----- the same account changes the admin website makes on Approve (applyCreate / applyRenew in index.html) ----- */
function nameKey_(u) { return encodeURIComponent(String(u).trim().toLowerCase()).replace(/\./g, '%2E'); }
function expiryOf_(t) { var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(t || '')); return m ? Utilities.parseDate(m[1] + '-' + m[2] + '-' + m[3] + ' 23:59:59', TZ, 'yyyy-MM-dd HH:mm:ss').getTime() + 999 : null; }
function dupHash_(f, v) {
  var n = f === 'name' ? String(v).trim().toLowerCase().replace(/\s+/g, ' ') : String(v).trim().toLowerCase();
  return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, 'ac-dup|' + f + '|' + n, Utilities.Charset.UTF_8).map(function (b) { return ('0' + ((b + 256) % 256).toString(16)).slice(-2); }).join('');
}

/* ===================================================================  v63: SERVER-SIDE VALUES ONLY  ===================================================================
 * Token balances and expiry dates are stored ONLY in Firebase users/<uid> and change ONLY (1) here, after a CONFIRMED payment whose paid amount covers the tokens / expiry
 * that were requested at the CURRENT Account Center prices (verifyPaid_), (2) by an admin in the Account Center / extension admin panel, or (3) by this script on an admin's Approve.
 * Nothing a customer's request carries is trusted: the amount, token count, expiry and the "win" (per-tab cost) fields are re-checked / cleaned here. */
var MAX_TOK_ = 1000000;
function numOk_(v, max) { var n = Number(v); return (isFinite(n) && n >= 0 && n <= (max || MAX_TOK_)) ? n : NaN; }
function priceOf_(acKey, pubKey) {                                                                   // Token Price / Rupees per day exactly as the admin saved them (ac_sync record { v: "<json>" }, public copy demo_config/*)
  var v = NaN, r = null;
  try { r = dbGet_('ac_sync/' + acKey); } catch (x) {}
  if (r && typeof r === 'object' && !r.del && r.v != null) { try { v = Number(JSON.parse(r.v)); } catch (x1) {} }
  if (!(v > 0)) { try { v = Number(dbGet_('demo_config/' + pubKey)); } catch (x2) {} }
  return (isFinite(v) && v > 0) ? v : 0;
}
function daysFrom_(iso, fromMs) {                                                                    // days from the payment day to the expiry day, both included (today = day 1) - same count as the extension
  var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(iso || '')); if (!m) return 0;
  var a = Utilities.formatDate(new Date(fromMs), TZ, 'yyyy-MM-dd').split('-');
  var n = Math.round((Date.UTC(+m[1], +m[2] - 1, +m[3]) - Date.UTC(+a[0], +a[1] - 1, +a[2])) / 864e5);
  return n < 0 ? 0 : n + 1;
}
/** v66: days (today .. current expiry, both included) an Unlimited account has already paid for; 0 when the account is not Unlimited / already expired. */
function paidDaysOf_(uid, fromMs) {
  try {
    var u = uid ? dbGet_('users/' + uid) : null, ex = u && u.unlimited ? Number(u.expiresAt) || 0 : 0;
    if (!(ex > fromMs)) return 0;
    return daysFrom_(Utilities.formatDate(new Date(ex), TZ, 'yyyy-MM-dd'), fromMs);
  } catch (e) { return 0; }
}
/** What the requested tokens / expiry cost at the admin's current prices, in paise. Throws a readable reason when the request cannot be priced. */
function expectedPaise_(rec, fromMs) {
  var d = rec.data || {}, renew = rec.kind === 'renew';
  if (d.unlimited) {
    var days = daysFrom_(d.expiry, fromMs); if (days < 1) throw new Error('the Unlimited request has no valid expiry date');
    if (renew) days -= paidDaysOf_(d.uid, fromMs);                                                    // v66: PRO-RATED - the days the account has already paid for (today .. its current Unlimited expiry) are not charged again, same as the extension
    if (days < 1) throw new Error('the requested expiry date is not later than the date the account is already paid until');
    var rpd = priceOf_('rupeesPerDay', 'rupeesPerDay'); if (!(rpd > 0)) throw new Error('Rupees per day is not set in the Account Center');
    return Math.round(days * rpd * 100);
  }
  var q = numOk_(renew ? d.add : d.tokens); if (!(q > 0)) throw new Error('the request has no valid token count');
  var tp = priceOf_('tokenPrizeRupees', 'tokenPrice'); if (!(tp > 0)) throw new Error('Token Price is not set in the Account Center');
  return Math.round(q * tp * 100);
}
/** Returns '' when the confirmed payment covers the request, otherwise the reason it must be reviewed by an admin. */
function verifyPaid_(rec, ps) {
  try {
    var paid = Math.round((Number(ps && ps.amount) || 0) * 100), need = expectedPaise_(rec, Number(ps && ps.at) || Date.now());
    if (paid + 1 < need) return 'Paid ' + rs_(paid / 100) + ' but the requested ' + (rec.data && rec.data.unlimited ? 'Unlimited expiry' : 'tokens') + ' cost ' + rs_(need / 100) + ' at the current prices - held for admin review (approve it manually if it is correct).';
    return '';
  } catch (e) { return 'Could not verify the paid amount (' + String(e && e.message || e) + ') - held for admin review.'; }
}
/** v66b: LAST LINE OF DEFENCE - whatever path confirmed a payment, it is applied only if the bank message's time is strictly after the moment the QR code was opened. '' = fine. */
function timeProblem_(id, ps) {
  var hi = Number(ps && ps.txHi) || 0; if (!hi) return '';
  var o = qrOpenOf_(id); if (o && hi <= o) return 'Payment Failed: the payment time (' + fmtMs_(hi) + ') is not after the QR code was opened (' + fmtMs_(o) + ')';
  return '';
}
/** v64: short public tag of a creator UID (payment_status is publicly readable, so the UID itself is never written there). */
function uidTag_(u) { return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, 'ac-cu|' + String(u || ''), Utilities.Charset.UTF_8).map(function (b) { return ('0' + ((b + 256) % 256).toString(16)).slice(-2); }).join('').slice(0, 24); }
/** v64: '' when the request belongs to the session that paid for it, otherwise the reason it must be reviewed by an admin. */
function ownerProblem_(rec, ps) {
  if (!rec || !rec.creatorUid) return 'This request has no creator UID (made by an older version of the extension) - held for admin review.';
  if (ps && ps.cu && ps.cu !== uidTag_(rec.creatorUid)) return 'The bank credit was confirmed for a different payment screen than the one that stored this request - held for admin review.';
  if (rec.kind === 'renew' && String((rec.data && rec.data.uid) || '') !== String(rec.creatorUid)) return 'The renewal targets an account that is not the creator of the request - held for admin review.';
  return '';
}
/** Per-tab screen costs only: tokSingle1 / tokDual1 / tokDual2 / tokWin{2..4}. Every other key a request tries to carry (tokens, unlimited, expiresAt, used, disabled ...) is dropped. */
function cleanWin_(w) {
  var out = {}; w = (w && typeof w === 'object') ? w : {};
  var c = function (v) { var n = Number(v); return (isFinite(n) && n >= 1 && n <= 1000) ? Math.round(n * 100) / 100 : null; };
  ['tokSingle1', 'tokDual1', 'tokDual2'].forEach(function (k) { var n = c(w[k]); if (n !== null) out[k] = n; });
  if (w.tokWin && typeof w.tokWin === 'object') {
    var tw = {}; ['2', '3', '4'].forEach(function (i) { var e = w.tokWin[i]; if (!e || typeof e !== 'object') return; var o = {}; ['s1', 'd1', 'd2'].forEach(function (k) { var n = c(e[k]); if (n !== null) o[k] = n; }); if (Object.keys(o).length) tw[i] = o; });
    if (Object.keys(tw).length) out.tokWin = tw;
  }
  return out;
}
function applyCreate_(d) {
  var email = String(d.gmail || '').trim().toLowerCase(), u = String(d.user || ''), key = nameKey_(u);
  if (!u || !email || !d.password) throw new Error('This request has no account details.');
  var claimPath = 'usernames/' + key, tag = 'pending:' + Utilities.getUuid().slice(0, 12);
  var c = db_('put', claimPath, { uid: tag, gmail: email, user: u }, { 'if-match': 'null_etag' });        // claim the username only if it is free
  if (c.getResponseCode() === 412) {
    var cur = dbGet_(claimPath), live = false;
    if (cur && cur.uid && String(cur.uid).indexOf('pending:') !== 0) live = dbGet_('users/' + cur.uid) !== null;
    if (live || (cur && String(cur.uid).indexOf('pending:') === 0)) throw new Error('That username already exists. Reject this request.');
    c = db_('put', claimPath, { uid: tag, gmail: email, user: u });                                        // a leftover claim of a deleted account
  }
  if (c.getResponseCode() !== 200) throw new Error('Database write failed (' + c.getResponseCode() + ').');
  var sr = UrlFetchApp.fetch('https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=' + API_KEY, { method: 'post', contentType: 'application/json', payload: JSON.stringify({ email: email, password: String(d.password), returnSecureToken: true }), muteHttpExceptions: true });
  var sj = JSON.parse(sr.getContentText());
  if (sr.getResponseCode() !== 200) {
    try { db_('delete', claimPath); } catch (x) {}
    var em = sj && sj.error && sj.error.message || '';
    throw new Error(/EMAIL_EXISTS/.test(em) ? 'That Gmail is already used by another account.' : (em || 'Could not create the login.'));
  }
  var uid = sj.localId, t = d.unlimited ? 0 : (numOk_(d.tokens) || 0), otpOn = !!d.otpOn;   // v63: a count that is not a plain number 0 .. 1,000,000 becomes 0
  var prof = { user: u, name: d.name || '', mobile: d.mobile || '', gmail: email, otpOn: otpOn, pw: d.password, tokens: t, used: 0, unlimited: !!d.unlimited, createdAt: Date.now() };
  if (otpOn && d.otpSecret) prof.authenticatorKey = d.otpSecret;
  var win = cleanWin_(d.win); for (var k in win) prof[k] = win[k];                                        // v63: ONLY the per-tab screen costs are accepted from a request
  prof.winLimit = Math.min(4, Math.max(1, parseInt(d.winLimit, 10) || 4));
  if (t > 0 || d.unlimited) { if (t > 0) prof.lastAdded = t; prof.addSeq = 1; prof.lastAddKind = d.unlimited ? 'unl' : 'tok'; }   // v91: what was added last (the extension's Available Tokens pop-up shows tokens or the Unlimited symbol)
  var ex = expiryOf_(d.expiry); if (ex) prof.expiresAt = ex;
  var idx = { uid: uid, gmail: email, user: u }; if (otpOn) idx.otp = true;
  var multi = {}; multi['users/' + uid] = prof; multi['usernames/' + key] = idx;
  [['name', d.name], ['user', u]].forEach(function (p) {                                                  // duplicate index (hashes only)
    if (p[1] == null || !String(p[1]).trim()) return;
    var h = dupHash_(p[0], p[1]); multi['dupidx/' + p[0] + '/' + h] = uid;
    if (p[0] === 'name') multi['usernames/~nm~' + h] = { uid: uid, user: '~name' };
  });
  var w = db_('patch', '', multi);
  if (w.getResponseCode() !== 200) {                                                                       // undo: free the username, delete the new login
    try { db_('delete', claimPath); } catch (x) {}
    try { UrlFetchApp.fetch('https://identitytoolkit.googleapis.com/v1/accounts:delete?key=' + API_KEY, { method: 'post', contentType: 'application/json', payload: JSON.stringify({ idToken: sj.idToken }), muteHttpExceptions: true }); } catch (x) {}
    throw new Error('Database write failed (' + w.getResponseCode() + ').');
  }
  return 'Account created: ' + u;
}
function applyRenew_(d, rec) {
  if (!d.uid) throw new Error('This request has no account.');
  // v64: OWNERSHIP - a renewal may only change the account of the person who created the request (never another user's tokens / Unlimited / expiry). Not overridable.
  if (!rec || !rec.creatorUid || String(rec.creatorUid) !== String(d.uid)) throw new Error('Renewal refused: the request was not created by the signed-in owner of this account (no creator UID, or it differs from the account). Nothing was changed.');
  var cur = dbGet_('users/' + d.uid); if (!cur) throw new Error('This account no longer exists.');
  var upd = {}, now = Date.now();
  // v94: EVERYTHING ACCUMULATES - a renewal never removes the existing token balance or an existing expiry date.
  //   expiresAt    = the Unlimited end date while an Unlimited plan is stored, otherwise the token end date
  //   tokExpiresAt = the token balance's own end date while an Unlimited plan is stored
  var planOn = !!cur.unlimited, curEx = Number(cur.expiresAt) || 0, curTx = Number(cur.tokExpiresAt) || 0, curTok = Number(cur.tokens) || 0;
  if (d.unlimited) {
    upd.unlimited = true; upd.addSeq = (cur.addSeq || 0) + 1; upd.lastAddKind = 'unl';
    var ex = expiryOf_(d.expiry);
    if (planOn) {
      // already Unlimited: the end date is EXTENDED (never shortened); the token balance and its own end date stay exactly as they are
      if (ex) upd.expiresAt = Math.max(ex, curEx);
    } else {
      // tokens-only account -> Unlimited: the date the tokens had moves to tokExpiresAt (so the tokens keep their own end date), expiresAt becomes the Unlimited end
      if (curTok > 0 && curEx > 0) upd.tokExpiresAt = curEx;
      if (ex) upd.expiresAt = ex; else upd.expiresAt = null;
    }
  }
  else {
    var add = numOk_(d.add) || 0; if (add < 1) throw new Error('This request has no tokens to add.');   // v63: plain number 1 .. 1,000,000 only
    upd.tokens = curTok + add;                       // added ON TOP of the balance that is already there
    upd.lastAdded = add; upd.addSeq = (cur.addSeq || 0) + 1;
    upd.lastAddKind = 'tok';
    // v95: the balance accumulates (old + added). Adding tokens gives the tokens "No Expiry": the token end date is removed for good.
    // A RUNNING Unlimited plan keeps its own end date; an ended plan is closed.
    upd.tokExpiresAt = null;
    if (planOn && curEx > now) { /* Unlimited end date stays */ }
    else { if (planOn) upd.unlimited = false; upd.expiresAt = null; }
  }
  var multi = {}; Object.keys(upd).forEach(function (k) { multi['users/' + d.uid + '/' + k] = upd[k]; });
  var w = db_('patch', '', multi);
  if (w.getResponseCode() !== 200) throw new Error('Database write failed (' + w.getResponseCode() + ').');
  return 'Account renewed.';
}

/* ===================================================================  Payment SMS  ===================================================================
 * The admin website (Account Center > Payment SMS API) creates the API key (Firebase sms_config/apiKey) and shows this web app's URL as the endpoint.
 * An SMS-forwarder app on the phone that receives the bank SMS POSTs it here:   <web app URL>?action=sms&key=<API key>
 *   key     : in the URL (key=...) or in the body (key / apikey / api_key)
 *   message : the SMS text - body field message / sms / text / body / content (JSON or form fields), or the whole body as plain text
 * Checks: 1) the API key  2) the SMS contains the word "credited" (and not "debited")  3) the credited amount equals the FIXED amount of a pending request.
 * On a match the request gets paymentStatus = 'successful' (payment_requests/<id>) and payment_status/<id> is written; the extension polls that public node and
 * tells the customer "Payment successful". Approving the account is still done by the admin. A credit SMS that arrives before the request exists is kept
 * (sms_credits) and matched when the request is mailed. Every SMS is used once; a credit and a request match only when they are within SMS_WINDOW_MS. */
var SMS_KEYWORD   = 'credited';
var SMS_WINDOW_MS = 2 * 60 * 60 * 1000;      // a credit SMS and a request must be at most 2 hours apart (either one first)
var SMS_KEEP_MS   = 3 * 24 * 60 * 60 * 1000; // unmatched credits are forgotten after 3 days

function smsSame_(a, b) { a = String(a); b = String(b); if (a.length !== b.length) return false; var d = 0; for (var i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0; }
function smsHash_(t) { return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, 'ac-sms|' + String(t).toLowerCase().replace(/\s+/g, ' ').trim(), Utilities.Charset.UTF_8).map(function (b) { return ('0' + ((b + 256) % 256).toString(16)).slice(-2); }).join(''); }
/** The amount (in paise) written next to the word "credited": every "Rs / INR / ₹ <number>" is a candidate, the one nearest to "credited" wins. */
function smsAmount_(sms) {
  var low = String(sms).toLowerCase(), ci = low.indexOf(SMS_KEYWORD), best = null, bd = 1e9, m, re = /(?:rs\.?|inr|\u20B9)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)/gi;
  while ((m = re.exec(sms)) !== null) { var v = Math.round(parseFloat(m[1].replace(/,/g, '')) * 100); if (isNaN(v)) continue; var d = Math.abs(m.index - ci); if (d < bd) { bd = d; best = v; } }
  if (best === null) { re = /([0-9][0-9,]*\.[0-9]{2})/g; while ((m = re.exec(sms)) !== null) { var v2 = Math.round(parseFloat(m[1].replace(/,/g, '')) * 100); var d2 = Math.abs(m.index - ci); if (!isNaN(v2) && d2 < bd) { bd = d2; best = v2; } } }
  return best;
}
function dbQuery_(path, qs) {
  var r = UrlFetchApp.fetch(DB_URL + '/' + dbPath_(path) + '.json?' + qs, { method: 'get', headers: { Authorization: 'Bearer ' + token_() }, muteHttpExceptions: true });
  if (r.getResponseCode() !== 200) throw new Error('Database query failed (' + r.getResponseCode() + '): ' + String(r.getContentText()).slice(0, 200) + ' - publish the latest database.rules.json.');
  return JSON.parse(r.getContentText());
}
/** Marks one request as paid: payment_requests/<id> (admin) + payment_status/<id> (public read - the customer's extension polls it). */
function smsMarkPaid_(id, paise, rec, tx) {
  var now = Date.now(), amount = paise / 100, multi = {};
  multi['payment_requests/' + id + '/paymentStatus'] = 'successful'; multi['payment_requests/' + id + '/paidAt'] = now; multi['payment_requests/' + id + '/paidAmount'] = amount;
  multi['payment_requests/' + id + '/paymentMessage'] = 'Payment Completed';                    // shown as "Payment Successful" in Customer Requests (extension + website)
  multi['payment_status/' + id] = { status: 'successful', amount: amount, at: now, cu: rec && rec.creatorUid ? uidTag_(rec.creatorUid) : '', txHi: tx && tx.hi ? tx.hi : null };
  var w = db_('patch', '', multi);
  if (w.getResponseCode() !== 200) throw new Error('Database write failed (' + w.getResponseCode() + ').');
  // v14 (replaced by v15 above): no e-mail here any more. The request mail goes to Gmail ONLY when the customer presses 'Submit Request' (action 'mail'); a payment confirmed by the bank SMS just marks the request paid.
}
/* ===================================================================  v21: AUTOMATIC ACCOUNT CREATION / RENEWAL AFTER PAYMENT  ===================================================================
 * ROOT CAUSE of "paid, Payment Successful shown, but no account": the request stayed 'pending' after the payment was confirmed. Only an admin page that happened to be OPEN and signed in
 * (the admin website or the extension's admin panel) approved it. With nobody online nothing ever created the account.
 * Now the script itself does it: right after the payment is confirmed (actions 'paidmail' / 'check') and again every minute (processReplies trigger) every confirmed payment whose request is still
 * 'pending' is approved with the same code as the Approve button (decide_ -> applyCreate_ / applyRenew_). decide_ claims the request first, so the website / extension / this script can never apply it twice. */
function autoApprovePaid_(id) {
  var props = PropertiesService.getScriptProperties();
  var ps = dbGet_('payment_status/' + id); if (!ps || ps.status !== 'successful') return 'payment not confirmed';
  var rq = dbGet_('payment_requests/' + id); if (!rq || !reqOk_(rq)) return 'request not stored yet';
  if (String(rq.status || '') !== 'pending') return 'already ' + rq.status;
  if (rq.appliedAt) { reconcileApplied_(); return 'finalized (the account was already updated)'; }                    // v71
  var held = timeProblem_(id, ps) || verifyPaid_(rq, ps) || ownerProblem_(rq, ps);                                                 // v63 / v64: the confirmed payment must cover the requested tokens / expiry at the current prices AND belong to the request's creator
  if (held) {
    props.setProperty('auto_' + id, '99');
    try { var he = {}; he['payment_requests/' + id + '/autoError'] = held.slice(0, 250); he['payment_requests/' + id + '/autoErrorAt'] = Date.now(); db_('patch', '', he); } catch (xh) {}
    console.error('Auto-create ' + id + ': ' + held);
    return 'HELD: ' + held;
  }
  var tries = Number(props.getProperty('auto_' + id)) || 0; if (tries >= 3) return 'gave up after 3 tries - see the request in Customer Requests';
  props.setProperty('auto_' + id, String(tries + 1));
  var res = decide_('approve', id, 'auto');
  if (res.kind === 'approved') {
    props.deleteProperty('auto_' + id);
    if (rq.autoError) { try { var ce = {}; ce['payment_requests/' + id + '/autoError'] = null; db_('patch', '', ce); } catch (x0) {} }
    try { mailResult_(res); } catch (x1) {}                                                                 // the usual "Approved: <id>" mail
    return 'approved - ' + (res.note || '');
  }
  var note = String(res.note || '');
  if (/decided somewhere else|being processed/i.test(note)) { props.setProperty('auto_' + id, String(tries)); return 'being handled elsewhere'; }       // not an error
  if (/already exists|already used|no account details|no tokens|no longer exists|no account/i.test(note)) props.setProperty('auto_' + id, '99');      // retrying cannot help
  try { var fe = {}; fe['payment_requests/' + id + '/autoError'] = note.slice(0, 250); fe['payment_requests/' + id + '/autoErrorAt'] = Date.now(); db_('patch', '', fe); } catch (x2) {}
  console.error('Auto-create ' + id + ': ' + note);
  return 'FAILED: ' + note;
}
/** v72: EVERYTHING that must follow a confirmed payment, done right away inside the same request (a real MacroDroid SMS, a website Test Message or a credit matched later all take the same road):
 *  1) the request is approved + the tokens / Unlimited expiry are applied (status 'approved' at once), 2) the "Customer Request - Payment Successful" e-mail goes to the admin (once per request - payMail_ is guarded).
 *  Before v72 the e-mail and the approval of a Test Message waited for the extension's final call or the one-minute trigger. Each step is isolated: a failure in one never stops the other. */
function finishPaid_(id) {
  if (!id) return;
  try { autoApprovePaid_(id); } catch (xf1) { console.error('finishPaid_ approve ' + id + ': ' + xf1); }
  try {
    var rq = dbGet_('payment_requests/' + id), ps = dbGet_('payment_status/' + id);
    if (rq && reqOk_(rq) && ps && ps.status === 'successful') {
      var paise = Math.round((Number(ps.amount) || Number(rq.amount) || 0) * 100);
      if (rq.paymentStatus !== 'successful') { var pu = {}; pu['payment_requests/' + id + '/paymentStatus'] = 'successful'; pu['payment_requests/' + id + '/paidAt'] = Number(ps.at) || Date.now(); pu['payment_requests/' + id + '/paidAmount'] = paise / 100; pu['payment_requests/' + id + '/paymentMessage'] = 'Payment Completed'; db_('patch', '', pu); rq.paymentStatus = 'successful'; rq.paidAt = Number(ps.at) || Date.now(); }
      payMail_(id, rq, paise);
      if (rq.paymentMailError) { var cl = {}; cl['payment_requests/' + id + '/paymentMailError'] = null; db_('patch', '', cl); }
    }
  } catch (xf2) {
    console.error('finishPaid_ mail ' + id + ': ' + xf2);
    try { var fe = {}; fe['payment_requests/' + id + '/paymentMailError'] = String(xf2 && xf2.message || xf2).slice(0, 200); db_('patch', '', fe); } catch (xf3) {}
  }
}
function sweepAutoApprove_() {
  try { reconcileApplied_(); } catch (xr) { console.error('reconcileApplied_: ' + xr); }                                // v71: a paid + applied request can never stay 'pending'
  var ps = dbGet_('payment_status') || {};
  Object.keys(ps).forEach(function (id) {
    var e = ps[id]; if (!e || typeof e !== 'object' || e.status !== 'successful') return;
    try { autoApprovePaid_(id); } catch (err) { console.error('Auto-create ' + id + ': ' + err); }
  });
}
/** Run from the editor: does the sweep right now and logs what happened (same as the every-minute trigger). */
function createPaidAccountsNow() { var lock = LockService.getScriptLock(); lock.waitLock(25000); try { sweepAutoApprove_(); Logger.log('Done - see Executions / Customer Requests for the result.'); } finally { lock.releaseLock(); } }

/** Gmail notification "Customer Request - Payment Successful" (once per request, sent ONLY by the final action 'paidmail' or a Resend): details table + "Payment Successful" at the bottom. No Approve / Reject, no screenshot. */
/** v18: every minute (time trigger = always the newest saved code, whichever web-app deployment the extension / MacroDroid use): each payment that was confirmed (payment_status/<id> = successful, written when the bank SMS matched)
 *  whose request is now stored gets its ONE "Customer Request - Payment Successful" mail. Nothing is sent for a payment that is not confirmed, and pressing Payment Completed alone never sends anything.
 *  Mail failures are written on the request (paymentMailError) so Customer Requests shows why. payment_status entries older than 3 days are removed (the extension watches 24 h). */
function sweepPaidMails_() {
  var ps = dbGet_('payment_status') || {}, now = Date.now(), props = PropertiesService.getScriptProperties();
  Object.keys(ps).forEach(function (id) {
    var e = ps[id]; if (!e || typeof e !== 'object') return;
    var at = Number(e.at) || 0;
    if (at && now - at > 3 * 864e5) { try { db_('delete', 'payment_status/' + id); } catch (x) {} return; }          // forget old entries
    if (e.status !== 'successful' || props.getProperty('paid_' + id)) return;                                     // not paid / already mailed
    if (at && now - at > 3 * 3600 * 1000) return;                                                                 // a request is stored within seconds - older than 3 h with no mail means it is not coming
    var rq = null; try { rq = dbGet_('payment_requests/' + id); } catch (x1) {}
    if (!rq || !reqOk_(rq)) return;                                                                               // the request is not stored yet: try again next minute
    var paise = Math.round((Number(e.amount) || Number(rq.amount) || 0) * 100);
    try {
      if (rq.paymentStatus !== 'successful') { var pu = {}; pu['payment_requests/' + id + '/paymentStatus'] = 'successful'; pu['payment_requests/' + id + '/paidAt'] = at || now; pu['payment_requests/' + id + '/paidAmount'] = paise / 100; pu['payment_requests/' + id + '/paymentMessage'] = 'Payment Completed'; db_('patch', '', pu); rq.paymentStatus = 'successful'; rq.paidAt = at || now; }
      payMail_(id, rq, paise);
      if (rq.paymentMailError) { var cl = {}; cl['payment_requests/' + id + '/paymentMailError'] = null; db_('patch', '', cl); }
    } catch (err) {
      console.error('Payment Successful mail for ' + id + ': ' + err);
      try { var fe = {}; fe['payment_requests/' + id + '/paymentMailError'] = String(err && err.message || err).slice(0, 200); fe['payment_requests/' + id + '/emailStatus'] = 'failed'; fe['payment_requests/' + id + '/emailError'] = String(err && err.message || err).slice(0, 200); fe['payment_requests/' + id + '/emailAt'] = Date.now(); db_('patch', '', fe); } catch (x2) {}
    }
  });
}
/** Run from the editor: sends a sample "Customer Request - Payment Successful" mail to ADMIN_EMAIL (also asks for the Gmail / Mail permission) so you can check delivery and layout. */
function testPaidMail() {
  var id = 'testpaid' + Date.now().toString(36), r = { kind: 'create', status: 'pending', amount: 100, createdAt: Date.now(), customer: { name: 'Test Customer', mobile: '9999999999' }, data: { user: 'test', password: 'x', gmail: 'test@gmail.com', mobile: '9999999999', tokens: 10, winLimit: 3 } };
  var m = build_(id, Object.assign({}, r, { paymentStatus: 'successful', paidAt: Date.now() }), DASHBOARD_URL);
  MailApp.sendEmail({ to: ADMIN_EMAIL, subject: 'Customer Request - Payment Successful' + subjectTag_(id), htmlBody: m.html, body: m.text, name: 'Auto Clicker Requests' });
  Logger.log('Sample Payment Successful mail sent to ' + ADMIN_EMAIL + ' - check the inbox (and Spam).');
}
/** Run from the editor: sweeps right now (same as the every-minute trigger) and logs what it did. */
function sendPaidMailsNow() { var lock = LockService.getScriptLock(); lock.waitLock(25000); try { sweepPaidMails_(); Logger.log('Done - see Executions for any error.'); } finally { lock.releaseLock(); } }

/** The subject reads exactly "Customer Request - Payment Successful". Every mail with the SAME subject is grouped by Gmail into one conversation, and Gmail then hides the parts it thinks repeat an
 *  earlier mail behind "Show quoted text" (this is what hid the details and the bottom status). A few INVISIBLE zero-width characters that differ per request keep each mail in its own conversation.
 *  Set SUBJECT_TAG = false to turn this off (the subject is then byte-for-byte plain, but Gmail may fold repeated mails). */
var SUBJECT_TAG = true;
function subjectTag_(id) {
  if (!SUBJECT_TAG) return '';
  var h = 0, t = String(id) + ':' + Date.now(); for (var i = 0; i < t.length; i++) h = (h * 31 + t.charCodeAt(i)) >>> 0;
  var out = ''; for (var b = 11; b >= 0; b--) out += ((h >> b) & 1) ? '\u200C' : '\u200B';
  return out;
}
function payMail_(id, r, paise) {
  var props = PropertiesService.getScriptProperties();
  if (props.getProperty('paid_' + id)) return;
  if (!reqOk_(r)) { try { r = dbGet_('payment_requests/' + id) || r; } catch (xq) {} }
  if (!reqOk_(r)) return;                                                                                  // v17: never mail an empty request
  var rec = {}; Object.keys(r || {}).forEach(function (k) { rec[k] = r[k]; });
  rec.paymentStatus = 'successful'; rec.paidAt = Number(rec.paidAt) || Date.now(); rec.shot = '';          // the Payment Successful mail never carries the screenshot
  var m = build_(id, rec, String(DASHBOARD_URL).replace(/\/+$/, '')), amt = rs_(paise / 100);
  MailApp.sendEmail({ to: ADMIN_EMAIL, subject: 'Customer Request - Payment Successful' + subjectTag_(id), htmlBody: m.html, body: m.text, name: 'Auto Clicker Requests' });   // v17: exactly this subject
  props.setProperty('paid_' + id, String(Date.now()));
  var up = {}; up['payment_requests/' + id + '/paymentMailAt'] = Date.now();                  // the website / extension show that the admin was told
  if (!(r && r.emailStatus)) { up['payment_requests/' + id + '/emailStatus'] = 'sent'; up['payment_requests/' + id + '/emailAt'] = Date.now(); }
  try { db_('patch', '', up); } catch (x) {}
}
/** Website > Account Center > MacroDroid Messages: every message that reaches the endpoint with a valid API key is kept (macrodroid_messages/<id>) with its date + time. */
/** A mailer call is JSON that carries MAIL_KEY (website / extension). Everything else - action=sms in the URL or body, plain text, form fields, anything from MacroDroid - is a MacroDroid message. */
function isMacro_(e) {
  var p = (e && e.parameter) || {};
  if (String(p.action || '') === 'sms') return true;
  var raw = (e && e.postData && e.postData.contents) || '';
  try { var j = JSON.parse(raw); if (j && typeof j === 'object' && !Array.isArray(j)) return !(j.key === MAIL_KEY || j.action === 'decide' || j.action === 'check' || j.rec); } catch (x) {}
  return true;
}
function rawMsg_(e) {
  var p = (e && e.parameter) || {}, raw = (e && e.postData && e.postData.contents) || '';
  var names = ['message', 'sms', 'text', 'body', 'content', 'msg', 'sms_message', 'notification', 'data'];
  for (var i = 0; i < names.length; i++) if (p[names[i]]) return String(p[names[i]]);
  return raw;
}
var TESTMSG_ = false, SENDER_ = '';   // v67: set by smsApi_ when the website's "Test Message" button sent the message (kept in the list whatever the result) / the sender it carries
function macLog_(type, sms, result, extra) {
  try {
    if (MD_ && MD_.skipped) return;                                                                  // rate-limited wrong-key spam: nothing to add
    // v28: ONLY a "Credited" SMS that matched a QR payment ("Payment Successful") stays in MacroDroid Messages. Credited-without-QR-match, duplicates ("already processed"), "Ignored ... Debited" and other messages are not saved (the entry mdl_log_ wrote first is removed again).
    if (TESTMSG_ && !(type === 'credited' && extra && (extra.matched || extra.failed)) && type !== 'rejected') type = 'test';   // v67: a Test Message is always kept (Test Messages list) unless it was a confirmed / failed payment (MacroDroid Messages list)
    if (!(type === 'credited' && extra && (extra.matched || extra.failed)) && type !== 'test' && type !== 'rejected') type = 'other';   // v69: every message that is neither a confirmed / failed payment nor a test is KEPT and listed under Others (it used to be removed)
    if (MD_ && MD_.id) {                                                                              // v11: the entry already exists (mdl_log_) - complete it instead of writing a second one
      var patch = { result: mdl_clean_(result) }; if (type) patch.type = type;
      if (SENDER_) patch.sender = SENDER_; if (TESTMSG_) patch.testMsg = true;
      if (extra) for (var k0 in extra) patch[k0] = extra[k0];
      if (mdl_update_(MD_.id, patch)) return;
    }
    var rec = { at: Date.now(), type: type || 'other', message: mdl_clean_(sms).slice(0, 2000), result: mdl_clean_(result) };
    if (SENDER_) rec.sender = SENDER_; if (TESTMSG_) rec.testMsg = true;   // fallback only when mdl_log_ could not store the entry
    if (extra) for (var k in extra) rec[k] = extra[k];
    rec.time = Utilities.formatDate(new Date(rec.at), TZ, 'dd/MM/yyyy - hh:mm:ss a');
    if (MD_ && MD_.queued && MD_.at) { rec.at = MD_.at; try { mdl_unqueue_(MD_.at); } catch (x1) {} }   // v12: the late-save copy of this same request is removed, this entry replaces it
    var w = db_('post', 'macrodroid_messages', rec);
    if (w.getResponseCode() !== 200) { Utilities.sleep(400); w = db_('post', 'macrodroid_messages', rec); }   // one retry
    if (w.getResponseCode() !== 200) console.error('macLog_ failed ' + w.getResponseCode() + ': ' + String(w.getContentText()).slice(0, 200));
  } catch (x) { console.error('macLog_: ' + x); }
}
/** v28: the account holder's name for a confirmed QR payment: the payer's name written in the bank SMS ("... from NAME", "by NAME", "Sender: NAME"), else the customer name of the matched request / QR screen. */
function macName_(sms, id) {
  var n = '';
  if (id) {
    try { var w = dbGet_('pay_waiting/' + id); if (w && (w.name || w.customerName)) n = String(w.name || w.customerName); } catch (x2) {}   // v31: the QR screen now carries the customer's name - available the moment the SMS is matched
    if (!n) { try { var c = dbGet_('payment_requests/' + id + '/customer'); if (c && c.name) n = String(c.name); } catch (x1) {} }
    if (!n) { try { var d = dbGet_('payment_requests/' + id + '/data'); if (d && d.name) n = String(d.name); } catch (x3) {} }
  }
  return n;   // v30: the customer's name from the QR payment request (the website also looks it up live by reqId, so a request stored a moment later still shows its name)
}
/** v32: Live Payment Detection PRE-CHECK for the extension.
 *  The extension cannot read macrodroid_messages (admin-only rules), so the script does the whole round trip and reports the result:
 *    1) a test message tagged with the extension's check id is written into macrodroid_messages (the list shown on the website > MacroDroid Messages),
 *    2) the entry is READ BACK from that same Firebase node and its tag is compared,
 *    3) only then { verified: true } is returned. Any failure returns { verified: false, message: ... }.
 *  The test entry is removed again after it was verified (MD_CHECK_KEEP = true keeps it visible in the website list). */
var MD_CHECK_KEEP = false;
function mdTestApi_(q, id) {
  var t0 = Date.now(), entryId = null;
  try {
    var now = new Date();
    var entry = { at: now.getTime(), time: Utilities.formatDate(now, TZ, 'dd/MM/yyyy - hh:mm:ss a') + ' IST', message: 'Live Payment Detection check (' + (q.src === 'website' ? 'website' : 'extension') + ')', type: 'test', method: 'POST', source: (q.src === 'website' ? 'livecheck' : 'extension'), checkId: id, result: 'Test request received from the extension and read back (Live Payment Detection check)' };
    entryId = (mdl_db_('POST', 'macrodroid_messages', entry) || {}).name || null;
    if (!entryId) return json_({ ok: false, verified: false, checkId: id, message: 'The test message could not be stored in macrodroid_messages.' });
    var back = mdl_db_('GET', 'macrodroid_messages/' + entryId);                               // read it back from the node the website list shows
    if (!back || back.checkId !== id || (back.source !== 'extension' && back.source !== 'livecheck')) { try { mdl_db_('DELETE', 'macrodroid_messages/' + entryId); } catch (xd0) {} return json_({ ok: false, verified: false, checkId: id, message: 'The test message was stored but could not be read back from macrodroid_messages.' }); }
    if (!MD_CHECK_KEEP && q.keep !== true) { try { mdl_db_('DELETE', 'macrodroid_messages/' + entryId); } catch (xd) { mdl_err_(xd); } }
    return json_({ ok: true, verified: true, received: true, checkId: id, entryId: entryId, ms: Date.now() - t0, version: String(SCRIPT_VERSION).split(' ')[0], build: SCRIPT_BUILD });
  } catch (err) {
    if (entryId) { try { mdl_db_('DELETE', 'macrodroid_messages/' + entryId); } catch (xd2) {} }
    mdl_err_(err);
    return json_({ ok: false, verified: false, checkId: id, message: String(err && err.message || err).slice(0, 300) });
  }
}
function smsApi_(e, method) {
  try {
    var p = (e && e.parameter) || {}, raw = (e && e.postData && e.postData.contents) || '', body = {};
    try { var j = JSON.parse(raw); if (j && typeof j === 'object' && !Array.isArray(j)) body = j; } catch (x) {}
    var pick = function (o, names) { for (var i = 0; i < names.length; i++) if (o[names[i]] != null && String(o[names[i]]) !== '') return String(o[names[i]]); return ''; };
    var KN = ['api-key', 'key', 'apikey', 'api_key', 'apiKey', 'x-api-key'];   // v14: 'api-key' is the preferred name (Apps Script cannot read HTTP headers, so MacroDroid sends it as a URL parameter or body field)
    var key = pick(p, KN) || pick(body, KN);
    var MN = ['message', 'sms', 'text', 'body', 'content', 'msg', 'sms_message', 'notification', 'data'];
    var sms = pick(p, MN) || pick(body, MN);
    if (!sms && raw && !Object.keys(body).length) sms = raw;                                        // plain-text body
    var saved = dbGet_('sms_config/apiKey');
    TESTMSG_ = String(p.src || body.src || '') === 'webtest'; SENDER_ = mdl_clean_(pick(p, ['sender', 'from', 'address']) || pick(body, ['sender', 'from', 'address'])).slice(0, 60);   // v67
    if (!saved || !key || !smsSame_(key, saved)) {                                                   // wrong / missing key: still logged (at most once a minute, so nobody can flood the list)
      var ch = CacheService.getScriptCache();
      if (!ch.get('mac_rej')) { ch.put('mac_rej', '1', 60); macLog_('rejected', sms || raw, 'Rejected (' + (method || 'POST') + '): ' + (key ? 'invalid' : 'missing') + ' API key.'); }
      return jm_({ ok: false, message: 'Invalid API key.' });
    }   // 1) API key
    sms = String(sms).replace(/^\s+|\s+$/g, ''); if (!sms) { macLog_('test', '', 'Empty test request (no message text).'); return jm_({ ok: false, message: 'No SMS text received (send it as "message").' }); }
    var low = sms.toLowerCase();
    var cfgKw = '', cfgSender = ''; try { cfgKw = String(dbGet_('sms_config/keyWord') || '').toLowerCase().replace(/^\s+|\s+$/g, ''); cfgSender = String(dbGet_('sms_config/senderWord') || '').toLowerCase().replace(/^\s+|\s+$/g, ''); } catch (xc) {}   // v79: Message Settings (website) - the word the message must contain (default "credited") and the text the sender name must contain
    SMS_KEYWORD = cfgKw || 'credited';
    if (cfgSender && String(SENDER_ || '').toLowerCase().indexOf(cfgSender) < 0) { macLog_('other', sms, 'Rejected: the sender "' + (SENDER_ || '(none)') + '" does not contain "' + cfgSender + '".'); return jm_({ ok: true, ignored: true, rejected: true, message: 'Rejected: the sender name does not contain "' + cfgSender + '".' }); }   // sender check - any letter case, the text may sit anywhere inside the name ("AB" accepts "2abC")
    if (low.indexOf(SMS_KEYWORD) < 0) { macLog_(/\btest\b/i.test(sms) ? 'test' : 'other', sms, 'Ignored: no "' + SMS_KEYWORD + '" in the message.'); return jm_({ ok: true, ignored: true, message: 'Ignored: the SMS does not contain "' + SMS_KEYWORD + '".' }); }   // 2) keyword
    if (low.indexOf('debited') >= 0) { macLog_('other', sms, 'Ignored: the message also contains "debited".'); return jm_({ ok: true, ignored: true, message: 'Ignored: the SMS also contains "debited".' }); }
    var paise = smsAmount_(sms); if (paise === null || paise < 1) { macLog_('credited', sms, 'Could not find the credited amount.'); return jm_({ ok: false, message: 'Could not find the credited amount in the SMS.' }); }
    var h = smsHash_(sms), now = Date.now(), credits = dbGet_('sms_credits') || {}, tx = smsTime_(sms, now), txX = { txAt: tx.lo, txTime: fmtTx_(tx), txSrc: tx.src };   // v65: the transaction date / time written in the raw body (else the time the message was received)
    Object.keys(credits).forEach(function (k) { if (now - Number(credits[k] && credits[k].at || 0) > SMS_KEEP_MS) { try { db_('delete', 'sms_credits/' + k); } catch (x) {} delete credits[k]; } });
    if (credits[h]) { macLog_('credited', sms, 'Duplicate: this message was already processed.', { amount: paise / 100 }); return jm_({ ok: true, duplicate: true, message: 'This SMS was already processed.' }); }
    if (true) {                                                                                      // v14 FAST PATH (first, so the extension is told within a second): a QR payment screen that is open RIGHT NOW (pay_waiting/<id>, written by the extension) with exactly this amount
      var wid = smsMatchWaiting_(paise, now, tx);
      if (wid === null) {                                                                           // v64: two different customers are paying exactly this amount right now - the credit is NOT given to either of them
        db_('put', 'sms_credits/' + h, { at: now, amount: paise, used: false, ambiguous: true, tx: tx });
        macLog_('credited', sms, 'Not assigned: several customers are paying exactly this amount at the same time - approve the right request by hand.', { amount: paise / 100, matched: false });
        return jm_({ ok: true, matched: false, ambiguous: true, message: 'Credit of ' + rs_(paise / 100) + ' not assigned automatically: more than one customer is paying this exact amount right now.' });
      }
      if (wid) {
        db_('put', 'sms_credits/' + h, { at: now, amount: paise, used: true, reqId: wid, tx: tx });
        macLog_('credited', sms, 'Payment confirmed for the open QR screen ' + wid + '.', { amount: paise / 100, matched: true, reqId: wid, qrAt: qrOpenOf_(wid), name: macName_(sms, wid), txAt: txX.txAt, txTime: txX.txTime, txSrc: txX.txSrc });
        try { finishPaid_(wid); } catch (xa0) { console.error('Auto-create ' + wid + ': ' + xa0); }   // v72: approve + Payment Successful e-mail right now   // v70: EVERY confirmed QR payment (timed or not, extension open or closed) adds the tokens / Unlimited time right now - it no longer waits for the extension's final call (a customer who backed out never makes it)
        return jm_({ ok: true, matched: true, id: wid, amount: paise / 100, message: 'Payment of ' + rs_(paise / 100) + ' confirmed for the open QR screen ' + wid + '.' });
      }
    }
    var pcfg = payCfg_(), pend = dbQuery_('payment_requests', 'orderBy=' + encodeURIComponent('"status"') + '&equalTo=' + encodeURIComponent('"pending"')) || {}, hit = null, owners = {};
    Object.keys(pend).forEach(function (id) {                                                        // 3) amount = the request's fixed amount (oldest unpaid pending request of ONE creator wins)
      var r = pend[id]; if (!r || r.paymentStatus === 'successful') return;
      if (Math.round((Number(r.amount) || 0) * 100) !== paise) return;
      var at = Number(r.createdAt) || 0; if (now - at > SMS_WINDOW_MS || at - now > 5 * 60 * 1000) return;
      var wi0 = payReqWinInfo_(id, tx, pcfg, r); if (wi0.why) { noteFail_(id, wi0.why, wi0.open); return; }                  // v65: the transaction time must be strictly after the QR code was opened and inside the valid window
      owners[r.creatorUid ? String(r.creatorUid) : 'legacy:' + id] = 1;
      if (!hit || at < hit.at) hit = { id: id, at: at };
    });
    if (hit && Object.keys(owners).length > 1) {                                                     // v64: different creators hold requests for this exact amount - never guess whose payment it is
      db_('put', 'sms_credits/' + h, { at: now, amount: paise, used: false, ambiguous: true, tx: tx });
      macLog_('credited', sms, 'Not assigned: pending requests of several customers have exactly this amount - approve the right one by hand.', { amount: paise / 100, matched: false });
      return jm_({ ok: true, matched: false, ambiguous: true, message: 'Credit of ' + rs_(paise / 100) + ' not assigned automatically: several customers have a pending request with this exact amount.' });
    }
    if (!hit) {                                                                                      // nothing waiting yet: keep the credit for a request that is sent a little later
      db_('put', 'sms_credits/' + h, { at: now, amount: paise, used: false, tx: tx });
      var nw = WIN_NOTE_ ? ' Not approved: ' + WIN_NOTE_ + '.' : '';                                 // v65: say WHY a credit that matched an amount was refused
      if (WIN_FAIL_) {                                                                               // v66: the amount matched a QR code but the message is NOT strictly after its opening time -> 'Payment Failed' + the specific reason (rejected as invalid and listed under Other Messages)
        var why1 = String(WIN_FAIL_.why || ''); why1 = why1.charAt(0).toUpperCase() + why1.slice(1);
        macLog_('credited', sms, 'Invalid payment (rejected): ' + why1 + '.', { amount: paise / 100, matched: false, invalid: true, failReason: why1, reqId: WIN_FAIL_.id, qrAt: WIN_FAIL_.open, name: macName_(sms, WIN_FAIL_.id), txAt: txX.txAt, txTime: txX.txTime, txSrc: txX.txSrc });
        return jm_({ ok: true, matched: false, failed: true, message: 'Payment Failed: ' + why1 + '.' });
      }
      macLog_('credited', sms, 'Credit saved; no pending request with this amount yet.' + nw, { amount: paise / 100, matched: false, txAt: txX.txAt, txTime: txX.txTime, txSrc: txX.txSrc });
      return jm_({ ok: true, matched: false, message: 'Credit of ' + rs_(paise / 100) + ' saved; no pending request with this amount yet.' + nw });
    }
    smsMarkPaid_(hit.id, paise, pend[hit.id], tx);
    db_('put', 'sms_credits/' + h, { at: now, amount: paise, used: true, reqId: hit.id, tx: tx });
    try { finishPaid_(hit.id); } catch (xa1) { console.error('Auto-create ' + hit.id + ': ' + xa1); }   // v72: approve + Payment Successful e-mail right now   // v70: the account is updated at once (the QR screen may already be gone)
    macLog_('credited', sms, 'Payment confirmed for request ' + hit.id + '.', { amount: paise / 100, matched: true, reqId: hit.id, qrAt: qrOpenOf_(hit.id), name: macName_(sms, hit.id), txAt: txX.txAt, txTime: txX.txTime, txSrc: txX.txSrc });
    return jm_({ ok: true, matched: true, id: hit.id, amount: paise / 100, message: 'Payment of ' + rs_(paise / 100) + ' confirmed for request ' + hit.id + '.' });
  } catch (err) { macLog_('', '', 'Error while processing: ' + String(err && err.message || err).slice(0, 300)); return jm_({ ok: false, message: String(err && err.message || err) }); }   // v11: a crash is written into the entry's Result
}
/** v14: the extension registers every OPEN QR payment screen as pay_waiting/<id> = { amount (rupees), createdAt, seenAt (heartbeat every 30 s), kind }. A credit SMS whose amount equals one of them
 *  (screen still alive = seen within 3 minutes, not yet matched) marks it paid at once: payment_status/<id> = successful (public) - the extension shows "Payment Successful" and the request is applied. */
var WAIT_ALIVE_MS = 3 * 60 * 1000;
var WIN_FAIL_ = null;   // v66: the QR screen / request whose time check failed for the current SMS (the one opened last): { id, why, open }
function noteFail_(id, why, open) { WIN_NOTE_ = why; if (!WIN_FAIL_ || (Number(open) || 0) >= WIN_FAIL_.open) WIN_FAIL_ = { id: id, why: why, open: Number(open) || 0 }; }
/** v66: the exact moment (server time, ms) the QR code of a request / screen was opened. */
function qrOpenOf_(id) {
  var t = 0;
  try { var w = dbGet_('pay_waiting/' + id); if (w) t = Number(w.openedAt) || 0; } catch (x) {}
  if (!t) { try { t = Number(dbGet_('payment_requests/' + id + '/qrOpenedAt')) || 0; } catch (x2) {} }
  if (!t) { try { t = Number(dbGet_('payment_requests/' + id + '/createdAt')) || 0; } catch (x3) {} }
  return t;
}
var WIN_NOTE_ = '';   // v65: why the last credit was NOT assigned because of its time (shown in the macrodroid_messages result)
function smsMatchWaiting_(paise, now, tx) {                                                          // returns the request id, '' (no open screen) or null (AMBIGUOUS: screens of several different creators)
  WIN_NOTE_ = ''; WIN_FAIL_ = null;
  var w = null; try { w = dbGet_('pay_waiting'); } catch (x) { return ''; }
  if (!w) return '';
  var cfg = payCfg_(), live = {};                                                                    // v64: one entry per CREATOR UID (the freshest screen of that creator)
  Object.keys(w).forEach(function (id) {
    var r = w[id]; if (!r || typeof r !== 'object' || r.matched) return;
    if (Math.round((Number(r.amount) || 0) * 100) !== paise) return;
    var win = payWinOf_(r, cfg), seen = Number(r.seenAt) || Number(r.createdAt) || 0;
    if (win.timed) { if (now > win.end + PAY_GRACE_MS) return; }                                      // v65: a TIMED screen is tracked on the server until its window is over - open, closed or cancelled in the extension
    else if (now - seen > WAIT_ALIVE_MS) return;                                                     // an untimed screen must be alive (heartbeat seen within 3 minutes)
    var why = payTxCheck_(tx, win); if (why) { noteFail_(id, why, win.open); return; }                            // v65: transaction time strictly after the QR opened, and inside the window
    var at = Number(r.createdAt) || 0, cu = r.creatorUid ? String(r.creatorUid) : 'legacy:' + id, rank = Math.max(seen, Number(r.renewedAt) || 0, win.open);
    if (!live[cu] || rank > live[cu].seen || (rank === live[cu].seen && at < live[cu].at)) live[cu] = { id: id, at: at, seen: rank, cu: r.creatorUid || '' };
  });
  Object.keys(w).forEach(function (id) { var r = w[id]; var seen = r && (Number(r.seenAt) || Number(r.createdAt)) || 0; if (now - seen > 24 * 3600 * 1000 && !(r && r.timed && now < payWinOf_(r, cfg).end + PAY_GRACE_MS)) { try { db_('delete', 'pay_waiting/' + id); } catch (x) {} } });   // forget stale ones
  var keys = Object.keys(live);
  if (!keys.length) return '';
  if (keys.length > 1) return null;                                                                  // v64: a hijacker can no longer win by out-heart-beating a real customer: with two creators the credit goes to nobody automatically
  var hit = live[keys[0]];
  var multi = {}; multi['pay_waiting/' + hit.id + '/matched'] = true; multi['pay_waiting/' + hit.id + '/matchedAt'] = now;
  multi['payment_status/' + hit.id] = { status: 'successful', amount: paise / 100, at: now, cu: hit.cu ? uidTag_(hit.cu) : '', txHi: tx && tx.hi ? tx.hi : null };
  var wr = db_('patch', '', multi); if (wr.getResponseCode() !== 200) throw new Error('Database write failed (' + wr.getResponseCode() + ').');
  try { var rq = dbGet_('payment_requests/' + hit.id); if (rq) { var up = {}; up['payment_requests/' + hit.id + '/paymentStatus'] = 'successful'; up['payment_requests/' + hit.id + '/paidAt'] = now; up['payment_requests/' + hit.id + '/paidAmount'] = paise / 100; up['payment_requests/' + hit.id + '/paymentMessage'] = 'Payment Completed'; db_('patch', '', up); } } catch (x2) {}   // v16: marking only - the e-mail is sent by the final action 'paidmail'
  return hit.id;
}

/* ===================================================================  v65: PAYMENT DURATION TIME (server side)  ===================================================================
 * Admin website > UPI Settings > Payment Duration Time saves demo_config/payDurOn (on / off) and demo_config/payDur (seconds).
 * While it is ON the extension registers every QR screen as pay_waiting/<id> = { amount, openedAt (Firebase SERVER time, never changeable), renewedAt (server time of the last QR refresh), dur, timed:true, ... } and stores the
 * request (status 'pending') right away. From then on THIS SCRIPT owns the timer - it keeps running when the extension is closed or the customer cancels the payment:
 *    - a credit SMS whose transaction time is strictly after openedAt and not later than the end of the window (renewedAt + duration) confirms the payment and the account is created at once (auto-approve);
 *    - sweepPayWindows_ (every minute, processReplies) REJECTS a still-unpaid request whose window is over (plus PAY_GRACE_MS for a late bank SMS) and removes the screen.
 * An open extension refreshes the QR code (same amount) and restarts the timer before the window is over (renewedAt moves forward), so an open screen never expires while the customer is looking at it.
 * Requests the customer already handed to the admin by hand (claim 'manual' = screenshot submitted) are never auto-rejected. */
var PAY_GRACE_MS = 2 * 60 * 1000;
function payCfg_() {
  var on = false, sec = 300;
  try { on = dbGet_('demo_config/payDurOn') === true; var n = Number(dbGet_('demo_config/payDur')); if (n >= 30 && n <= 86400) sec = Math.floor(n); } catch (x) {}
  return { on: on, sec: sec };
}
/** The valid window of one pay_waiting screen: open = server time the QR was first opened; end = end of the current timer window (0 = no timer). The window is the one the extension stored (dur), shortened to the admin's current value. */
function payWinOf_(r, cfg) {
  var open = Number(r.openedAt) || Number(r.createdAt) || 0, from = Math.max(Number(r.renewedAt) || 0, open), sec = Number(r.dur) || 0;
  if (!(sec >= 30 && sec <= 86400)) sec = cfg.sec;
  if (cfg.on && cfg.sec < sec) sec = cfg.sec;
  return { open: open, timed: r.timed === true, end: r.timed === true ? from + sec * 1000 : 0 };
}
function fmtMs_(ms) { return Utilities.formatDate(new Date(ms), TZ, 'dd/MM/yyyy - hh:mm:ss a'); }   // v66: no "IST" suffix
function fmtTx_(tx) { return tx.src === 'sms' ? Utilities.formatDate(new Date(tx.lo), TZ, 'dd/MM/yyyy - hh:mm:ss a') : Utilities.formatDate(new Date(tx.lo), TZ, 'dd/MM/yyyy - hh:mm:ss a') + ' (received)'; }   // v66: no "IST" suffix
/** '' = the transaction is inside the valid window, otherwise the reason. STRICT: a transaction at or before the moment the QR was opened never counts. A time written only to the minute covers the whole minute (the later end is used for "after open", the earlier start for "before the end"). */
function payTxCheck_(tx, win) {
  if (!win.open) return 'the time the QR code was opened is not known, so the payment time cannot be checked';   // v66b: strict - no opening time, no approval
  var late = tx.src === 'received' ? PAY_GRACE_MS : 0;
  if (tx.future) return 'the payment time (' + fmtTx_(tx) + ') is later than the correct current date and time (' + fmtMs_(Date.now()) + ')';   // v96: paid time higher than the real time = rejected
  if (tx.hi <= win.open) return 'the payment time (' + fmtTx_(tx) + ') is not after the QR code was opened (' + fmtMs_(win.open) + ')';
  if (tx.dHi && tx.dHi <= win.open) return 'the payment date in the message is before the QR code was opened (' + fmtMs_(win.open) + ')';
  if (win.timed && tx.lo > win.end + late) return 'the payment time (' + fmtTx_(tx) + ') is after the Payment Duration window ended (' + fmtMs_(win.end) + ')';
  if (win.timed && tx.dLo && tx.dLo > win.end) return 'the payment date in the message is after the Payment Duration window ended (' + fmtMs_(win.end) + ')';
  return '';
}
function payReqWinInfo_(id, tx, cfg, rq) {                                                          // the same check for a request: the stored screen (pay_waiting/<id>) or, without one, the request's own server-side QR opening time (qrOpenedAt, v66)
  try {
    var w = dbGet_('pay_waiting/' + id), win = null;
    if (w && typeof w === 'object') win = payWinOf_(w, cfg);
    else { var o = Number(rq && rq.qrOpenedAt) || 0; if (o) win = { open: o, timed: false, end: 0 }; }
    if (!win) { var c0 = Number(rq && rq.createdAt) || 0; win = { open: c0, timed: false, end: 0 }; }   // v66b: an older request without a stored opening time is checked against its creation time
    return { why: payTxCheck_(tx, win), open: win.open };
  } catch (x) { return { why: 'the payment time could not be checked against the QR opening time', open: 0 }; }   // v66b: strict - an error never lets a payment through
}
function payReqWin_(id, tx, cfg, rq) { return payReqWinInfo_(id, tx, cfg, rq).why; }
var MON_ = { jan: 1, january: 1, feb: 2, february: 2, mar: 3, march: 3, apr: 4, april: 4, may: 5, jun: 6, june: 6, jul: 7, july: 7, aug: 8, august: 8, sep: 9, sept: 9, september: 9, oct: 10, october: 10, nov: 11, november: 11, dec: 12, december: 12 };
function istMs_(y, mo, d, h, mi, s) { return Date.UTC(y, mo - 1, d, h, mi, s) - 330 * 60000; }          // a wall-clock time in IST -> epoch ms
/** The transaction date / time written in the raw body of the bank SMS (IST). Understands 09-11-26, 09/11/2026, 09.11.2026, 2026-11-09, 09-Nov-26, 09 Nov 2026, Nov 9, 2026, each with 10:35[:12][ am/pm] before or after it.
 *  Returns { lo, hi, src }: src 'sms' = a date AND time were found (lo..hi is the second, or the whole minute when no seconds are written); src 'received' = no usable time in the body -> the time the message reached the server
 *  (dLo / dHi then carry the day written in the message, when there was one). */
function smsTime_(sms, now) {
  var s = String(sms), c = [], m, re;
  function add(i, len, d, mo, y) { y = Number(y); if (y < 100) y += 2000; d = Number(d); mo = Number(mo); if (y >= 2000 && y <= 2100 && mo >= 1 && mo <= 12 && d >= 1 && d <= 31) c.push({ i: i, e: i + len, y: y, mo: mo, d: d }); }
  re = /(^|[^0-9.,])(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})(?![0-9])/g; while ((m = re.exec(s)) !== null) add(m.index + m[1].length, m[0].length - m[1].length, m[4], m[3], m[2]);
  re = /(^|[^0-9.,])(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4}|\d{2})(?![0-9])/g; while ((m = re.exec(s)) !== null) add(m.index + m[1].length, m[0].length - m[1].length, m[2], m[3], m[4]);
  re = /(^|[^0-9])(\d{1,2})(?:st|nd|rd|th)?[-\/ .,]*([A-Za-z]{3,9})[-\/ .,]*(\d{4}|\d{2})(?![0-9])/g; while ((m = re.exec(s)) !== null) { var mn = MON_[String(m[3]).toLowerCase()]; if (mn) add(m.index + m[1].length, m[0].length - m[1].length, m[2], mn, m[4]); else re.lastIndex = m.index + m[1].length + m[2].length; }   // v77: a false hit such as "1 on 26" must not swallow the real date "26/Oct/2026" - rescan right after its first number
  re = /(^|[^A-Za-z])([A-Za-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})(?![0-9])/g; while ((m = re.exec(s)) !== null) { var mn2 = MON_[String(m[2]).toLowerCase()]; if (mn2) add(m.index + m[1].length, m[0].length - m[1].length, m[3], mn2, m[4]); else re.lastIndex = m.index + m[1].length + m[2].length; }
  c.sort(function (a, b) { return a.i - b.i; });
  var best = null, bestTime = null;
  for (var k = 0; k < c.length && !bestTime; k++) {
    var after = /^[\s,@-]*(?:at|on)?[\s,@-]*(\d{1,2}):(\d{2})(?::(\d{2}))?\s*([AaPp])?\.?[Mm]?\.?/.exec(s.slice(c[k].e, c[k].e + 40));
    var before = after ? null : /(\d{1,2}):(\d{2})(?::(\d{2}))?\s*([AaPp])?\.?[Mm]?\.?[\s,@-]*(?:on)?[\s,@-]*$/.exec(s.slice(Math.max(0, c[k].i - 24), c[k].i));
    var t = after || before; if (!t) continue;
    var hh = Number(t[1]), mi = Number(t[2]), ss = t[3] != null ? Number(t[3]) : -1, ap = t[4] ? String(t[4]).toLowerCase() : '';
    if (ap) { if (hh < 1 || hh > 12) continue; hh = hh % 12 + (ap === 'p' ? 12 : 0); }
    if (hh > 23 || mi > 59 || ss > 59) continue;
    best = c[k]; bestTime = { h: hh, mi: mi, s: ss };
  }
  if (bestTime) {
    var lo = istMs_(best.y, best.mo, best.d, bestTime.h, bestTime.mi, bestTime.s < 0 ? 0 : bestTime.s), hi = bestTime.s < 0 ? lo + 59999 : lo;
    return { lo: lo, hi: hi, src: 'sms', future: lo > now || best.d > 0 && istMs_(best.y, best.mo, best.d, 0, 0, 0) > now };   // v97: a later DATE is also later than the live date                              // v96: a payment time LATER than the real current time (2 min clock tolerance) is flagged - payTxCheck_ rejects it (it used to fall back to the arrival time and be approved)
  }
  var tx = { lo: now, hi: now, src: 'received' };
  if (c.length) { tx.dLo = istMs_(c[0].y, c[0].mo, c[0].d, 0, 0, 0); tx.dHi = tx.dLo + 86399999; if (tx.dLo > now) tx.future = true; }   // v97: a message dated TOMORROW or later (no readable time) is later than the live date = rejected
  return tx;
}
/** Run from the editor: shows what smsTime_ reads from typical bank messages. */
function testSmsTime() {
  ['Rs. 100.00 credited to a/c XX1234 on 09-11-26 10:35:12 by UPI Ref 123456', 'INR 50.00 credited to A/c XX1234 on 09-Nov-2026 at 10:35 PM. Avl bal INR 999', 'Rs 1.00 credited to a/c XX1234 on 09-11-26 by a/c linked to VPA x@y (UPI Ref No 1234567890)', 'Your a/c is credited Rs.25 on 2026-11-09 22:15:30'].forEach(function (t) { var x = smsTime_(t, Date.now()); Logger.log(fmtTx_(x) + '  [' + x.src + ']  <-  ' + t); });
}
/** v66: every minute. An ABANDONED QR request is ERASED (payment_requests/<id> + pay_waiting/<id>), whether or not the extension / tab is still around:
 *   1) a TIMED screen (Payment Duration Time On) whose window (+ PAY_GRACE_MS for a late bank SMS) is over and that was never paid - an open extension keeps renewing the window, so this only happens when it was closed;
 *   2) an untimed screen nobody has refreshed for WAIT_ALIVE_MS;
 *   3) a pending QR request (it has qrOpenedAt) with no screen on the server whose heartbeat (seenAt) stopped ABANDON_MS ago.
 * Never erased: a paid request, a request the customer handed in by hand (claim 'manual' / screenshot), a request being processed, a request an admin already decided. */
var ABANDON_MS = 5 * 60 * 1000;
function abandonErase_(id) {
  var rq = null; try { rq = dbGet_('payment_requests/' + id); } catch (e0) { return false; }
  if (rq) {
    var st = String(rq.status || '');
    if (st === 'processing') return false;                                                           // being decided right now - the next minute looks again
    if (st === 'pending' && rq.paymentStatus !== 'successful' && rq.claim !== 'manual' && !rq.shot) {
      try { var ps = dbGet_('payment_status/' + id); if (ps && ps.status === 'successful') return false; } catch (e1) {}   // paid in the meantime
      var d = db_('delete', 'payment_requests/' + id); if (d.getResponseCode() !== 200) { console.error('Abandoned request ' + id + ' not erased (' + d.getResponseCode() + ')'); return false; }
    }
  }
  try { db_('delete', 'pay_waiting/' + id); } catch (e2) {}
  return true;
}
function sweepPayWindows_() {
  var w = dbGet_('pay_waiting') || {}, cfg = payCfg_(), now = Date.now();
  Object.keys(w).forEach(function (id) {
    var r = w[id]; if (!r || typeof r !== 'object' || r.matched) return;
    var win = payWinOf_(r, cfg);
    if (r.timed === true) { if (!win.end || now <= win.end) return; }                          // v66b: erased as soon as the timer is over (the next minute sweep at the latest)
    else { var seen = Number(r.seenAt) || Number(r.createdAt) || 0; if (now - seen <= WAIT_ALIVE_MS) return; }
    try { abandonErase_(id); } catch (e) { console.error('Window sweep ' + id + ': ' + e); }
  });
  var pend = {}; try { pend = dbQuery_('payment_requests', 'orderBy=' + encodeURIComponent('"status"') + '&equalTo=' + encodeURIComponent('"pending"')) || {}; } catch (xq) { return; }
  Object.keys(pend).forEach(function (id) {
    var q = pend[id]; if (!q || typeof q !== 'object' || !q.qrOpenedAt || w[id]) return;            // only new-style QR requests, and only those without a screen (those are handled above)
    if (q.paymentStatus === 'successful' || q.claim === 'manual' || q.shot) return;
    var alive = Math.max(Number(q.seenAt) || 0, Number(q.qrOpenedAt) || 0, Number(q.createdAt) || 0);
    if (now - alive <= ABANDON_MS) return;
    try { abandonErase_(id); } catch (e3) { console.error('Abandon sweep ' + id + ': ' + e3); }
  });
}
/** Called when a request mail is sent: an unused credit of the same amount (received within SMS_WINDOW_MS) marks the new request as paid. */
function smsMatchRequest_(id, r) {
  if (!dbGet_('sms_config/apiKey')) return;                                                          // the SMS feature is not in use
  var paise = Math.round((Number(r && r.amount) || 0) * 100); if (paise < 1) return;
  var credits = dbGet_('sms_credits') || {}, now = Date.now(), hit = null, pcfg = payCfg_();
  Object.keys(credits).forEach(function (k) { var c = credits[k]; if (!c || c.used || c.ambiguous || Number(c.amount) !== paise || now - Number(c.at || 0) > SMS_WINDOW_MS) return; if (c.tx && payReqWin_(id, c.tx, pcfg, r)) return; if (!hit || c.at < hit.at) hit = { k: k, at: c.at }; });   // v65: a saved credit must also be strictly after the QR opened and inside the window
  if (!hit) return;
  smsMarkPaid_(id, paise, r);
  db_('patch', 'sms_credits/' + hit.k, { used: true, reqId: id });
  try { finishPaid_(id); } catch (xm) { console.error('finishPaid_ (credit matched later): ' + xm); }   // v72
}

/* ===================================================================  request mail  =================================================================== */
/** Last line of EVERY mail: the request id + the exact send time. Gmail folds text that repeats an earlier mail of the same thread into
 *  "Show quoted text / Hide quoted text" (or "..."). A unique subject (it carries the id) + a unique last line mean nothing in the mail
 *  repeats an earlier one, so Gmail has nothing to fold and the whole mail is always shown. Never put a blockquote / gmail_quote in a mail. */
function stamp_() { return Utilities.formatDate(new Date(), TZ, 'dd/MM/yyyy - hh:mm:ss a') + ' IST'; }
function uniqueFoot_(id) { return '<div style="margin:14px 0 0;color:#888;font-size:11px">Request ID: ' + esc_(id) + ' &middot; Sent: ' + esc_(stamp_()) + '</div>'; }
function uniqueFootText_(id) { return '\nRequest ID: ' + id + ' | Sent: ' + stamp_() + '\n'; }
function jm_(o) { try { o.version = String(SCRIPT_VERSION).split(' ')[0]; } catch (x0) {} try { o.logged = !!(MD_ && MD_.id); if (MD_ && MD_.id) o.logId = MD_.id; if (MD_ && MD_.skipped) o.skipped = true; if (MD_ && !MD_.id && !MD_.skipped) { o.logError = String(MD_.error || 'not stored in Firebase').slice(0, 300); if (MD_.queued) o.queued = true; } } catch (x) {} return json_(o); }   // v13: logged is true ONLY when the entry really exists in Firebase (before, a failed write that was only queued also said true); logError tells why
function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function esc_(v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function rs_(n) { return '₹' + (Math.round((Number(n) || 0) * 100) / 100).toLocaleString('en-IN'); }
function shotBlob_(shot, id) {
  var m = /^data:(image\/[a-z+.-]+);base64,(.+)$/i.exec(String(shot || '')); if (!m) return null;
  var ext = m[1].split('/')[1].replace('jpeg', 'jpg').replace(/[^a-z0-9]/gi, '');
  return Utilities.newBlob(Utilities.base64Decode(m[2]), m[1], 'payment-screenshot-' + id + '.' + ext);
}
function clean_(v) { return String(v == null ? '' : v).replace(/\s+/g, ' ').replace(/^[\s\-\u2013\u2014]+|[\s\-\u2013\u2014]+$/g, ''); }   // v16: trims spaces and any leading / trailing hyphen from a value
/** v17: a real request has the customer or the account data, and an amount. */
function reqOk_(r) { if (!r || typeof r !== 'object') return false; var c = r.customer || {}, d = r.data || {}; return !!((c.name || c.mobile || d.user || d.uid || d.gmail) && Number(r.amount) > 0); }
function details_(r) {
  var d = r.data || {};
  if (d.unlimited) { var x = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(d.expiry || '')); return 'Unlimited' + (x ? ' - [' + x[3] + '/' + x[2] + '/' + x[1] + ']' : ''); }
  var n = Number(r.kind === 'renew' ? d.add : d.tokens) || 0;
  return n > 0 ? '+' + n + ' token' + (n === 1 ? '' : 's') : clean_(r.summary);
}
/** "Label : value" - the colons of all rows sit in one straight vertical column. */
function colonRows_(rows) {
  return rows.map(function (p) {
    return '<tr><td style="padding:6px 0;color:#666;font-weight:600;vertical-align:top;white-space:nowrap">' + esc_(p[0]) + '</td>' +
      '<td style="padding:6px 10px;color:#666;font-weight:700;vertical-align:top;text-align:center">:</td>' +
      '<td style="padding:6px 0;color:#111;word-break:break-word;overflow-wrap:anywhere">' + esc_(clean_(p[1]) || (p[0] === 'Notes' ? '-' : '')) + '</td></tr>';
  }).join('');
}
function colonText_(rows) {
  var w = 0; rows.forEach(function (p) { w = Math.max(w, String(p[0]).length); });
  return rows.map(function (p) { var l = String(p[0]); while (l.length < w) l += ' '; return l + ' : ' + (clean_(p[1]) || (p[0] === 'Notes' ? '-' : '')); }).join('\n');
}
function build_(id, r, site) {
  var c = r.customer || {}, d = r.data || {}, renew = r.kind === 'renew';
  var typeLabel = renew ? 'Renewal Account' : 'Create Account';                                          // shown as "Type" in the mail and reused in the PDF file name
  var paid0 = String(r.paymentStatus || '') === 'successful';
  var hasShot = !paid0 && /^data:image\//i.test(String(r.shot || ''));                                      // v16: no screenshot in a Payment Successful mail
  var paid = String(r.paymentStatus || '') === 'successful';                                                 // v15: a confirmed payment -> the bottom of the mail says "Payment Successful" (no Approve / Reject)
  // Order: Type, Customer, Notes, Date & Time, Amount, Details, (extra account fields), Screenshot
  var cust = [c.name || d.name, c.mobile || d.mobile].filter(Boolean).join(' / ');
  var rows = [
    ['Type', typeLabel],                                                                                  // v20: order = Type, Customer, Notes, Date & Time ...
    ['Customer', cust],
    ['Notes', clean_(c.notes || r.notes) || '-'],                                                          // v20: Notes is ALWAYS present - a hyphen when empty
    ['Date & Time', Utilities.formatDate(new Date(Number(r.createdAt) || Date.now()), TZ, 'dd/MM/yyyy - hh:mm:ss a')],
    ['Amount', rs_(r.amount)],
    ['Details', details_(r)]
  ];
  if (!renew) rows.push(['Gmail', d.gmail], ['Mobile (account)', d.mobile], ['Tabs limit', d.winLimit != null ? d.winLimit : ''], ['OTP', d.otpOn ? 'On' : 'Off']);
  var paidTs = Number(r.paidAt) || Date.now();                                                               // v19: never empty - falls back to now, so the date and time are always shown
  var paidWhen = Utilities.formatDate(new Date(paidTs), TZ, 'dd/MM/yyyy, hh:mm:ss a');
  // v20: no "Payment" row any more - the green "Payment Successful" label at the bottom is the confirmation
  if (!paid) rows.push(['Screenshot', hasShot ? 'attached below' : 'none']);                              // the Screenshot line belongs to the Customer Request mail only
  rows = rows.filter(function (p) { return p[0] === 'Notes' || clean_(p[1]) !== ''; });                                       // v17: a row with no value is left out - no empty / dummy lines, no lone hyphens
  var enc = encodeURIComponent(id);
  var base = String(DASHBOARD_URL).replace(/\/+$/, '');                                                    // the buttons ALWAYS use DASHBOARD_URL (the 'site' argument is ignored on purpose)
  var a = base + '/?act=approve&req=' + enc, b = base + '/?act=reject&req=' + enc;                       // the buttons open the website with the action + request (the website reads act / req)
  // "Bulletproof" button: the colour sits on the <td> (works even where the <a> background is stripped), the padding is on the link and the text colour is forced, so it renders the same in Gmail (also dark mode), Outlook and Apple Mail.
  var btn = function (h, t, bg) {
    return '<td align="center" bgcolor="' + bg + '" style="background:' + bg + ';border-radius:8px;mso-padding-alt:12px 28px">' +
      '<a href="' + esc_(h) + '" target="_blank" style="display:inline-block;padding:12px 28px;font-family:Segoe UI,Arial,sans-serif;font-size:15px;font-weight:700;line-height:20px;color:#ffffff !important;text-decoration:none;border-radius:8px;white-space:nowrap"><font color="#ffffff">' + t + '</font></a></td>';
  };
  var gap = '<td width="12" style="width:12px;font-size:0;line-height:0">&nbsp;</td>';
  // The action block is built on its own and ALWAYS added to the mail - it never depends on hasShot / the screenshot.
  // Layout: title, details table, then the Approve / Reject buttons, and only AFTER them the optional screenshot - so a tall image can never push the buttons out of view.
  var actions =
    '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0 0 10px;border-collapse:separate"><tr>' + btn(a, 'Approve', '#2e7d32') + gap + btn(b, 'Reject', '#c62828') + '</tr></table>' +
    '<div style="color:#777;font-size:12px;margin:0 0 12px">Buttons not showing? Use these links: <a href="' + esc_(a) + '" style="color:#2e7d32;font-weight:600">Approve</a> | <a href="' + esc_(b) + '" style="color:#c62828;font-weight:600">Reject</a></div>';
  if (paid) actions = '<div style="margin:0 0 12px;padding:14px 16px;background:#e8f5e9;border:1px solid #a5d6a7;border-radius:8px;color:#1b5e20;font-size:16px;font-weight:700;text-align:center">&#10003; Payment Successful</div>';
  var html = '<div style="font-family:Segoe UI,Arial,sans-serif;max-width:560px;margin:auto;padding:18px;background:#fff;border:1px solid #e3e3e3;border-radius:12px">' +
    '<h2 style="margin:0 0 4px;color:#111">' + (paid ? 'Customer Request - Payment Successful:' : 'Customer Request:') + '</h2><div style="color:#888;font-size:12px;margin-bottom:14px">Advanced Auto Clicker</div>' +
    '<table style="border-collapse:collapse;font-size:14px;width:100%">' + colonRows_(rows) + '</table>' +
    '<div style="height:18px;line-height:18px;font-size:0">&nbsp;</div>' +
    actions +
    (paid ? '<div style="color:#999;font-size:11px;margin:4px 0 4px">The payment was verified automatically from the bank SMS. No approval is needed.</div>' : '<div style="color:#999;font-size:11px;margin:4px 0 4px">The buttons open your admin website (log in once), ask you to confirm, then update Firebase. The extension refreshes by itself. The attached PDF holds all these details with the screenshot.</div>') +
    '<div style="color:#bbb;font-size:10px;margin:2px 0 4px">Links go to ' + esc_(base) + ' &middot; script ' + esc_(String(SCRIPT_VERSION).split(' ')[0]) + '</div>' +
    (hasShot ? '<div style="margin:16px 0 4px;color:#666;font-weight:600;font-size:13px">Payment screenshot</div><img src="cid:shot" alt="Payment screenshot" style="max-width:100%;border:1px solid #ddd;border-radius:8px">' : '') +
    uniqueFoot_(id) +
    '</div>';
  var text = colonText_(rows) + (paid ? '\n\nPayment Successful\n' : '\n\nApprove: ' + a + '\nReject: ' + b + '\n') + uniqueFootText_(id);
  var pdfName = pdfName_(c.name, typeLabel);
  return { subject: paid ? 'Customer Request - Payment Successful' : 'New ' + (renew ? 'RENEW' : 'CREATE') + ' request - ' + rs_(r.amount) + (c.name ? ' - ' + c.name : '') + ' [#' + id + ']', html: html, text: text, rows: rows, pdfName: pdfName };
}

/** "[Customer Name] - [Request Type].pdf"  e.g. "John Doe - Create Account.pdf". Characters not allowed in file names are removed. */
function pdfName_(customerName, typeLabel) {
  var clean = function (v) { return String(v == null ? '' : v).replace(/[\\\/:*?"<>|\r\n\t]+/g, ' ').replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, ''); };
  return (clean(customerName) || 'Customer') + ' - ' + clean(typeLabel) + '.pdf';
}

/** The ONE PDF attachment: every detail of the mail's top section ("Label : value") + the payment screenshot embedded in the same document. Returns { pdf, imageEmbedded }. Built as a temporary Google Doc, exported, then trashed. */
function pdfBlob_(id, rows, shot, fileName) {
  var doc = DocumentApp.create('request-' + id), fileId = doc.getId(), embedded = false;
  try {
    var body = doc.getBody();
    body.setMarginTop(40); body.setMarginBottom(40); body.setMarginLeft(48); body.setMarginRight(48);
    body.appendParagraph('Customer request').setHeading(DocumentApp.ParagraphHeading.HEADING1);
    var sub = body.appendParagraph('Advanced Auto Clicker'); sub.editAsText().setForegroundColor('#888888').setFontSize(10);
    body.appendParagraph('');
    var t = body.appendTable(rows.map(function (p) { return [String(p[0]), ':', String(p[1] == null ? '' : p[1])]; }));
    t.setBorderWidth(0);
    t.setColumnWidth(0, 130); t.setColumnWidth(1, 16); t.setColumnWidth(2, 318);
    for (var i = 0; i < t.getNumRows(); i++) {
      var row = t.getRow(i);
      for (var j = 0; j < 3; j++) {
        var cell = row.getCell(j); cell.setPaddingTop(4); cell.setPaddingBottom(4); cell.setPaddingLeft(0); cell.setPaddingRight(j === 0 ? 4 : 0);
        var tx = cell.editAsText(); tx.setFontSize(11); tx.setBold(j < 2); tx.setForegroundColor(j === 2 ? '#111111' : '#555555');
      }
    }
    if (shot) {
      var hp = body.appendParagraph('Payment screenshot'); hp.setSpacingBefore(14); hp.editAsText().setBold(true).setFontSize(11);
      try {
        var img = body.appendImage(shot), w = img.getWidth(), h = img.getHeight(), k = Math.min(1, 460 / w, 520 / h);
        img.setWidth(Math.round(w * k)).setHeight(Math.round(h * k)); embedded = true;
      } catch (ie) { body.appendParagraph('(The screenshot could not be embedded; it is attached to the mail as a separate file.)'); }
    }
    doc.saveAndClose();
    var pdf = DriveApp.getFileById(fileId).getAs('application/pdf').setName(fileName || ('Request-' + id + '.pdf'));
    return { pdf: pdf, imageEmbedded: embedded || !shot };
  } finally { try { DriveApp.getFileById(fileId).setTrashed(true); } catch (x) {} }
}

/* =====================================================================  SETUP (once)  =====================================================================
 * 1. Firebase console > Project settings > Service accounts > "Generate new private key": a .json file downloads. KEEP IT PRIVATE.
 * 2. Apps Script > Project Settings (gear) > Script Properties > Add property:  name  SA_JSON   value = the WHOLE content of that .json file.
 * 3. Run setup() once from the editor (accept the permissions: Gmail, external requests, triggers). It checks Firebase and installs the 1-minute trigger.
 * 4. Deploy > Manage deployments > edit > New version (so doPost sends the new mails). The web app URL stays the same.
 * 5. Set DASHBOARD_URL above to your hosted website (the Approve / Reject buttons ALWAYS use it).
 * 6. The PDF needs the Docs + Drive permission: run test() once from the editor and accept it, then deploy a new version (step 4).
 * Approve / Reject mails are accepted only from ADMIN_EMAIL to ADMIN_EMAIL, only for request IDs this script mailed, and each mail is processed once.
 */

/* ===================================================================  MacroDroid logger (v11, built in)  ===================================================================
 * mdl_log_ is the FIRST call of doPost / doGet.  Do NOT add a separate MacroDroid_Logger file to this project (the same names would exist twice). */
var MDL_DB = DB_URL;
var MDL_NAMES = ["message", "sms", "text", "body", "content", "msg", "sms_message", "notification", "data"];

/* ---------- Firebase access (service account -> OAuth token -> REST) ---------- */
function mdl_token_() { return token_(); }   // v13: ONE shared Firebase login (the logger used its own copy before)

function mdl_db_(method, path, body) {
  var opt = { method: method, muteHttpExceptions: true, headers: { Authorization: "Bearer " + mdl_token_() } };
  if (body !== undefined) { opt.contentType = "application/json"; opt.payload = JSON.stringify(body); }
  var r = UrlFetchApp.fetch(MDL_DB + "/" + path + ".json", opt);
  var code = r.getResponseCode();
  if (code < 200 || code >= 300) {
    if (code === 401) CacheService.getScriptCache().remove("fb_token");   // stale token -> fetch a new one next time
    throw new Error("Firebase " + method + " /" + path + " -> HTTP " + code + " " + r.getContentText().slice(0, 200));
  }
  var t = r.getContentText();
  return t ? JSON.parse(t) : null;
}

/* ---------- read what MacroDroid sent ---------- */
function mdl_pick_(o) {
  if (!o || typeof o !== "object") return "";
  for (var i = 0; i < MDL_NAMES.length; i++) {
    var v = o[MDL_NAMES[i]];
    if (v !== undefined && v !== null && v !== "") return typeof v === "object" ? JSON.stringify(v) : String(v);
  }
  return "";
}

function mdl_parse_(e) {
  e = e || {};
  var par = e.parameter || {};
  var pd = e.postData || null;
  var raw = pd && pd.contents ? String(pd.contents) : "";
  var out = { raw: raw, text: "", key: String(par["api-key"] || par["x-api-key"] || par.key || par.apikey || par.api_key || par.apiKey || ""), action: String(par.action || ""), ctype: pd && pd.type ? String(pd.type) : "", json: null, bodyLen: raw.length };

  out.text = mdl_pick_(par);                       // ?message=...  or a form-encoded body (Apps Script already decodes it into e.parameter)
  var t = raw.trim();
  if (t) {
    var c = t.charAt(0);
    if (c === "{" || c === "[") {
      try {                                          // normal JSON body
        var j = JSON.parse(t);
        out.json = j;
        if (j && typeof j === "object" && !Array.isArray(j)) {
          if (!out.text) {
            out.text = mdl_pick_(j);
            if (!out.text) {                             // JSON without any message field (e.g. a MacroDroid test action)
              var ks = Object.keys(j).filter(function (k) { return ["key", "api-key", "x-api-key", "action", "test", "type", "source", "device", "time", "timestamp"].indexOf(k) < 0; });
              if (ks.length) out.text = JSON.stringify(j);
            }
          }
          var jk = j['api-key'] || j['x-api-key'] || j.key || j.apikey || j.api_key || j.apiKey; if (jk && !out.key) out.key = String(jk);
          if (j.action && !out.action) out.action = String(j.action);
        } else if (!out.text) { out.text = t; }
      } catch (err) {
        // BROKEN JSON: MacroDroid pastes {notification} / {sms_message} un-escaped, so quotes or new lines in the
        // SMS break JSON.parse.  Pull the text out by hand instead of losing the message.
        if (!out.text) {
          var m = new RegExp('"(?:' + MDL_NAMES.join("|") + ')"\\s*:\\s*"([\\s\\S]*?)"\\s*(?:,\\s*"[A-Za-z_]+"\\s*:|\\}\\s*$)').exec(t);
          out.text = m ? m[1] : t;
        }
        var k = /"(?:api-key|x-api-key|key)"\s*:\s*"([^"]+)"/.exec(t);
        if (k && !out.key) out.key = k[1];
      }
    } else if (!out.text) {
      out.text = t;                                  // plain-text body = the SMS itself
    }
  }
  return out;
}

/* internal calls of the website / extension (approve-reject, mail) are not MacroDroid messages */
function mdl_isInternal_(p) {
  var j = p.json;
  if (!j || typeof j !== "object" || Array.isArray(j)) return false;
  return j.action === "decide" || j.action === "check" || j.action === "mail" || (j.rec && j.id) || (typeof MAIL_KEY !== "undefined" && j.key === MAIL_KEY);
}

/* v14: a real bank SMS can carry control characters / broken surrogate pairs that Firebase refuses (a plain test message never does) - clean every text before it is stored */
function mdl_clean_(v) {
  return String(v == null ? '' : v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, ' ').replace(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])/g, '').replace(/(^|[^\uD800-\uDBFF])[\uDC00-\uDFFF]/g, '$1');
}
function mdl_amount_(text) {
  var m = /(?:rs\.?|inr|\u20B9)\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)/i.exec(text) || /([0-9][0-9,]*(?:\.[0-9]{1,2})?)\s*(?:rs\.?|inr|\u20B9)/i.exec(text);
  if (!m) return null;
  var n = parseFloat(m[1].replace(/,/g, ""));
  return isNaN(n) ? null : n;
}

/* ---------- main entry: NEVER throws, so it can never break doPost / doGet ---------- */
function mdl_log_(e, method) {
  var res = { ok: false, id: null, type: "other", skipped: false };
  try {
    var p = mdl_parse_(e);
    if (mdl_isInternal_(p)) { res.skipped = true; return res; }

    var text = String(p.text || "");
    var lower = text.toLowerCase();
    var type = (!text.trim() || /test/i.test(String(p.action || ""))) ? "test" : (lower.indexOf("credited") >= 0 && lower.indexOf("debited") < 0 ? "credited" : "other");
    var result = type === "test" ? "Test request (no message text)" : "Received";

    // check the API key against sms_config/apiKey (same key the website shows under Payment SMS API)
    var keyOk = false;
    try { var stored = mdl_db_("GET", "sms_config/apiKey"); keyOk = !!stored && String(stored) === p.key; } catch (err) { keyOk = true; /* cannot verify -> still log it as received */ }
    if (!keyOk) {
      var cache = CacheService.getScriptCache();
      if (cache.get("mdl_rej")) { res.skipped = true; return res; }          // wrong-key spam: at most one entry per minute
      cache.put("mdl_rej", "1", 60);
      type = "rejected"; result = "Rejected: wrong or missing API key";
    }

    var now = new Date();
    var entry = {
      at: now.getTime(),
      time: Utilities.formatDate(now, "Asia/Kolkata", "dd/MM/yyyy - hh:mm:ss a") + " IST",
      message: mdl_clean_(text).slice(0, 2000),
      type: type,
      method: method || "POST",
      ctype: p.ctype || "",
      result: result
    };
    if (p.raw) { var rw = String(p.raw); if (p.key) rw = rw.split(p.key).join("***"); entry.raw = mdl_clean_(rw).slice(0, 1500); }   // v12: the exact body MacroDroid sent (API key hidden) - shows why a message was read the way it was
    res.at = entry.at;
    var amt = mdl_amount_(text);
    if (amt !== null && type !== "test") entry.amount = amt;

    mdl_flush_();                                    // first send anything that failed earlier
    try {
      res.id = (mdl_db_("POST", "macrodroid_messages", entry) || {}).name || null;
      res.ok = !!res.id;
    } catch (err) {
      res.error = String(err && err.message || err); mdl_queue_(entry, err); res.queued = true;     // Firebase problem: keep the message, remember WHY, retry on the next request
    }
    res.type = type;
  } catch (err) {
    res.error = String(err && err.message || err); mdl_err_(err);
  }
  return res;
}

/* enrich an entry afterwards (result text, matched flag, amount, type); never throws */
function mdl_update_(id, patch) {
  try { if (id) mdl_db_("PATCH", "macrodroid_messages/" + id, patch); return true; }
  catch (err) { mdl_err_(err); return false; }
}

/* ---------- retry queue (script property, max 10 short entries) ---------- */
function mdl_queue_(entry, err) {
  mdl_err_(err);
  var props = PropertiesService.getScriptProperties();
  var q = []; try { q = JSON.parse(props.getProperty("MDL_QUEUE") || "[]"); } catch (x) { q = []; }
  entry.message = String(entry.message || "").slice(0, 300);
  entry.result = (entry.result || "") + " (saved late)";
  q.push(entry); if (q.length > 10) q = q.slice(-10);
  props.setProperty("MDL_QUEUE", JSON.stringify(q));
}
function mdl_unqueue_(at) {
  var props = PropertiesService.getScriptProperties(), raw = props.getProperty("MDL_QUEUE"); if (!raw) return;
  var q = []; try { q = JSON.parse(raw); } catch (x) { return; }
  q = q.filter(function (it) { return it && it.at !== at; });
  if (q.length) props.setProperty("MDL_QUEUE", JSON.stringify(q)); else props.deleteProperty("MDL_QUEUE");
}
function mdl_flush_() {
  var props = PropertiesService.getScriptProperties();
  var raw = props.getProperty("MDL_QUEUE");
  if (!raw) return;
  var q = []; try { q = JSON.parse(raw); } catch (x) { props.deleteProperty("MDL_QUEUE"); return; }
  var left = [];
  for (var i = 0; i < q.length; i++) { try { mdl_db_("POST", "macrodroid_messages", q[i]); } catch (err) { left.push(q[i]); } }
  if (left.length) props.setProperty("MDL_QUEUE", JSON.stringify(left)); else props.deleteProperty("MDL_QUEUE");
}
function mdl_err_(err) {
  try { PropertiesService.getScriptProperties().setProperty("MDL_LAST_ERROR", new Date().toISOString() + "  " + String(err && err.message || err).slice(0, 400)); } catch (x) {}
  console.error("MacroDroid logger: " + (err && err.message || err));
}

/* ---------- run these from the Apps Script editor (select function > Run) ---------- */
function mdl_selfTest() {
  // 1) fake MacroDroid POST with a BROKEN JSON body (quotes inside the SMS) and the real key
  var key = mdl_db_("GET", "sms_config/apiKey");
  var fake = { parameter: { action: "sms", key: key }, postData: { type: "application/json", contents: '{"message":"Rs. 1.00 credited to a/c XX1234 by "TEST" on 26-10-26"}' } };
  var r = mdl_log_(fake, "POST");
  Logger.log("log result: " + JSON.stringify(r));
  if (!r.id) { Logger.log("FAILED. Last error: " + PropertiesService.getScriptProperties().getProperty("MDL_LAST_ERROR")); return; }
  var back = mdl_db_("GET", "macrodroid_messages/" + r.id);
  Logger.log("stored: " + JSON.stringify(back));
  Logger.log("OK - open the website > MacroDroid Messages; the TEST entry is there (delete it with the Delete button).");
}
function mdl_status() {
  var p = PropertiesService.getScriptProperties();
  Logger.log("last error: " + (p.getProperty("MDL_LAST_ERROR") || "none"));
  Logger.log("queued (unsent): " + (p.getProperty("MDL_QUEUE") || "none"));
}

/* ---------- v13: connection self-check (run  diagnose  from the editor, or open <web app URL>?diag=<MAIL_KEY> in a browser to test the DEPLOYED version) ---------- */
function diagnose_() {
  var out = { ok: false, version: String(SCRIPT_VERSION).split(' ')[0], dbUrl: DB_URL, steps: [] }, sa = null, id = null;
  var step = function (name, fn) {
    try { var v = fn(); out.steps.push({ step: name, ok: true, info: v === undefined ? '' : String(v) }); return true; }
    catch (err) { out.steps.push({ step: name, ok: false, error: String(err && err.message || err).slice(0, 400) }); return false; }
  };
  var go = step('1 SA_JSON is set and readable', function () { sa = sa_(); return 'service account ' + sa.client_email + ' / project ' + sa.project_id; });
  go = go && step('2 SA_JSON project matches DB_URL', function () {
    if (sa.project_id && DB_URL.indexOf('https://' + sa.project_id) !== 0) throw new Error('SA_JSON belongs to project "' + sa.project_id + '" but DB_URL is ' + DB_URL + ' - generate the key in the SAME Firebase project as the database.');
    return 'same project';
  });
  go = go && step('3 Google login (OAuth token)', function () { CacheService.getScriptCache().remove('fb_token'); token_(); return 'token received'; });
  go = go && step('4 Read sms_config/apiKey', function () { var k = dbGet_('sms_config/apiKey'); if (!k) throw new Error('sms_config/apiKey is empty - open the website > Payment SMS API > Generate API Key.'); return 'API key found (' + String(k).length + ' characters)'; });
  go = go && step('5 Write one entry to macrodroid_messages', function () {
    var now = new Date(), r = db_('post', 'macrodroid_messages', { at: now.getTime(), time: Utilities.formatDate(now, TZ, 'dd/MM/yyyy - hh:mm:ss a') + ' IST', message: 'Diagnostic test entry - you may delete it.', type: 'test', method: 'DIAG', result: 'Written by diagnose()' });
    if (r.getResponseCode() !== 200) throw new Error('Firebase answered HTTP ' + r.getResponseCode() + ': ' + String(r.getContentText()).slice(0, 250));
    id = JSON.parse(r.getContentText()).name; return 'written as ' + id;
  });
  go = go && step('6 Read that entry back', function () { var b = dbGet_('macrodroid_messages/' + id); if (!b) throw new Error('The entry was written but cannot be read back.'); return 'found - open the website > MacroDroid Messages, the DIAG entry is there'; });
  out.ok = out.steps.every(function (x) { return x.ok; });
  try { out.lastLogError = PropertiesService.getScriptProperties().getProperty('MDL_LAST_ERROR') || 'none'; out.queuedUnsent = PropertiesService.getScriptProperties().getProperty('MDL_QUEUE') ? 'yes' : 'no'; } catch (x) {}
  return out;
}
function diagnose() { Logger.log(JSON.stringify(diagnose_(), null, 2)); }
