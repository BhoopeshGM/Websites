> **v108 - unified database rules + MacroDroid focus.** The website and the extension (v7.3.5) now share ONE `database.rules.json` (publish it before using this build). The website's account code follows the extension's model: passwords / authenticator keys are written to the admin-only `admin_vault/<uid>`, the username index carries only a random handle (`h`) and no `otp` flag, new accounts sign in with a handle e-mail, and the Added Accounts list merges the vault. MacroDroid > Message Settings and Test Message no longer auto-focus a field (the cursor appears only when you tap one). Upload ZIP / Folder opens the file picker directly.

> **v76 - Added Accounts:** the "-" before [Storage] is back; the Unlimited and Tokens parts stay whole and drop to the next line when the row is narrow. Extension v6.765: Payment notes under the QR = "Name - website UPI note" only (customer notes are separate); profile uses the word Unlimited everywhere; Unlimited/Tokens capitalised in expiry; leaving Unlimited in the extension admin Edit keeps the tokens.

> **v75 - Added Accounts wording.** `[Unlimited / Expiry - date]`, or `[Unlimited / Expiry - date] - [Tokens - N / Expiry - date]`; tokens only `[Tokens - N / Expiry - date]`; no "-" before [Storage]. Extension v6.764 Profile: `Unlimited / +N`, `<date> for unlimited / <date> for tokens`, follows status changes live.

> **v74 - Added Accounts.** The word "Unlimited" replaces the infinity symbol; "Unlimited / +N" when both are active. Edit: Unlimited Access (Unlimited / Cancel Unlimited + its own expiry date) with the Tokens box and its own Token Expiry Date below it; either can be changed. New field `users/<uid>/tokExpiresAt`. Extension v6.763 shows the same wording and honours the token end date.

> **v73 - Customer Requests wording, badges, Unlimited + tokens.** Details: `Unlimited / Expiry - dd/mm/yyyy` or `Tokens - N` (no expiry, no brackets); only a green "Payment Successful" on the right (no date / time); Added Accounts / Customer Requests / MacroDroid badges clear after you open and leave the section. `Code.gs`: tokens added to a RUNNING Unlimited plan are kept next to it. **Redeploy Code.gs as a New version.** Extension v6.762: Profile shows Available Tokens above Expiry Date, `Unlimited / +N` and `<date> for unlimited`; Unlimited is used first, tokens after its end date.

> **v72 - Test Messages behave like real payment SMS.** (1) `Code.gs` build 34: the moment a bank message (real MacroDroid SMS or the website's Test Message) is matched to a payment, the SAME request approves the request (tokens / Unlimited expiry applied) **and** sends the "Customer Request - Payment Successful" e-mail (once per request). Before, a Test Message waited for the extension or the one-minute trigger. (2) Customer Requests: the separate "Account now" line is gone - **Details** now reads `Unlimited - [expiry]` or `Tokens - +N / Expiry - dd/mm/yyyy`; a paid request shows **APPROVED** at once and every paid request shows "Email Payment Successful Sent to Admin" (a missing mail is sent from the page as a backup). **You must paste the new Code.gs and Deploy > Manage deployments > Edit > New version.**

> **v71 - Approved status + live tokens / expiry in Customer Requests.** (1) **Why a paid request stayed "PENDING":** when the account change had already been made but the status could not be saved at that moment, `Code.gs` put the request back to *pending* (and could even apply it a second time). Now the moment the tokens / expiry are changed the request is stamped `appliedAt`, the status save is retried, it is never released / re-applied afterwards, and a one-minute check (`reconcileApplied_`) finishes any leftover as **Approved**; the website also shows any request with `appliedAt` as Approved. Requests that are paid but really **held** (amount below the price, different owner ...) now show the reason in a **Note** line. (2) Customer Requests shows **Account now: [Tokens - N / Expiry - dd/mm/yyyy]** read live from the account, so it always shows the updated values. **To update:** paste `Code.gs` (build 33), deploy a NEW VERSION, upload this folder to Netlify, update the extension to v6.761. `database.rules.json` is unchanged.

> **v70 - payment after Back + Other Messages.** (1) `Code.gs` build 32: a confirmed QR payment now adds the tokens / Unlimited expiry **at once** in every case (timed or untimed QR, QR page open / closed / backed out); before, it waited for the extension's final call, which a customer who backed out never makes. (2) MacroDroid Messages: the **Test Message** button stays (its result is listed in Other Messages); the separate Test Messages history tab is removed; the tabs are **MacroDroid Messages** and **Other Messages** (renamed from Others) - test requests and test messages are listed in Other Messages. **To update:** paste `Code.gs`, deploy a NEW VERSION, upload this folder to Netlify, update the extension to v6.760.

> **v69 - Customer Requests / MacroDroid clean-up.** (1) Customer Requests: the bottom of every request shows ONLY **Delete** (the green "Payment Successful" bar and the Approve / Reject buttons are gone); above it the only e-mail line left is **Email Payment Successful Sent to Admin** with **Resend Email**. Leaving the page and coming back always opens the **All** tab. (2) MacroDroid Messages: new **Others** tab (every message that is neither a payment nor a test - `Code.gs` now keeps them instead of deleting them); leaving the page and coming back always opens MacroDroid Messages. **QR Opened** is shown above **Date & Time**; all times are `hh:mm:ss AM/PM` (no milliseconds). (3) `Code.gs` build 31 (the strict "payment time must be after the QR opening time" check was already enforced on every path - unchanged). **To update:** paste `Code.gs`, deploy a NEW VERSION, upload this folder to Netlify, update the extension to v6.759. `database.rules.json` is unchanged.

> **v68 - (1) Test Message: the pop-up closes the moment you press Send and the result is listed below. (2) Customer Requests: a QR request is cleared ONLY when its timer is complete (closing the extension alone no longer clears it); then it disappears at once. The extension no longer deletes it on close.

> **v67 - instant clean-up, remembered tab, Test Message.** (1) Closing / leaving the QR page in the extension now erases the unpaid request and its screen **at once** (the extension deletes it; new rule in `database.rules.json`), and the admin website erases a request the moment its timer ran out with no refresh (3 s) or the customer's screen is closed - no more finished-timer entries lingering. (2) Customer Requests remembers the tab you chose (Pending / Approved / Rejected) after you leave the page and come back. (3) MacroDroid Messages > **Test Message**: a pop-up asks for **Sender** and **Message**; Send posts it to the endpoint like a MacroDroid SMS (QR time check included) and the entry appears below (MacroDroid Messages if it confirmed / failed a payment, otherwise Test Messages), with the sender shown. **To update:** publish `database.rules.json`, deploy `Code.gs` (build 30) as a NEW version, upload this folder to Netlify, update the extension (v6.757).

> **v66b - strict time check + cleaner Customer Requests.** (1) `Code.gs` (build 29) refuses any bank message whose time is not strictly after the QR opening time on EVERY path: matching, saved credits, auto-approve and the admin's manual Approve (no override); the confirmed payment now carries its transaction time (`payment_status/<id>/txHi`) and is re-checked right before the account is changed; an unknown opening time or an error also refuses. (2) Customer Requests: a request still waiting at its QR code shows Customer, Notes, Username, Amount, Details, then the QR code + timer - **no Approve / Reject buttons** (the server decides). Requests the customer submitted by hand (screenshot) keep their buttons, otherwise nobody could approve them. (3) An abandoned request is erased the moment its timer is over (next minute sweep at the latest, no grace); the page hides it as soon as no QR refresh arrives for 15 s. **To update:** paste `Code.gs` and deploy a NEW VERSION - the entry in your screenshot (a 26/10 bank message approved for a 09/11 QR) came from an OLDER deployed script without the check.

> **v66 - QR request at once, server-side clean-up, exact QR time check.** (1) **Customer Requests:** the moment a customer opens the QR code in the extension a PENDING request appears here with the request type (CREATE / RENEW), PENDING status, customer details, the **active QR code** and a **countdown synchronised with the server** (`pay_waiting` timer: it restarts when the customer's QR refreshes). The **Password line is removed**. When the payment is confirmed the status changes to Approved by itself (live); a request you or the server rejects shows Rejected. (2) **Abandoned requests are erased by `Code.gs`** (every minute): timer over (+2 min grace for a late bank SMS) or - without a timer - no heartbeat for 5 minutes, even if the extension / tab was closed. A paid request, a request the customer submitted by hand (screenshot) and a request being processed are never erased. (3) **MacroDroid Messages:** "Transaction Date & Time" is now **Date & Time** and the **IST** suffix is gone; every message also shows **QR Opened** (the exact server time, to the millisecond, the QR code was opened - the request's `qrOpenedAt`). `Code.gs` approves a bank credit only if its time is **strictly after** the QR opening: valid = **Payment Successful**; earlier or equal = **Payment Failed** + the specific reason (kept in the list). (4) **Renew is pro-rated** (extension v6.756): `Code.gs` subtracts the days the account has already paid for. **To update:** publish `database.rules.json` (new `qrOpenedAt` / `seenAt` rules), paste `Code.gs` into Apps Script and deploy a NEW VERSION (build 28), upload this folder to Netlify (it now includes `qrcode.js`), update the extension to v6.756.

> **v65 - Payment Duration Time + transaction time check.** (1) New in UPI Settings, right after Payment Notes: **Payment Duration Time** - an On / Off switch (right side) and a scrollable Hours / Minutes / Seconds timer (tap the time; it is dimmed and locked while Off). Saved to `demo_config/payDurOn` / `demo_config/payDur`. (2) While On, the extension shows the countdown under the QR code and refreshes the QR (same amount) when it ends; **`Code.gs` keeps the timer on the server**: a credit SMS inside the window is auto-approved, an unpaid request whose window is over is auto-rejected (every minute, with 2 minutes grace for a late bank SMS), even if the extension is closed or the payment is cancelled. Requests the customer submitted by hand (screenshot) are never auto-rejected. (3) **MacroDroid Messages** now show **Transaction Date & Time** right after the Amount, read from the raw body; the server approves a payment only if that time is strictly after the QR code was opened (server time) and inside the window. **To update:** publish `database.rules.json` in Firebase > Realtime Database > Rules, paste `Code.gs` into Apps Script and deploy a NEW VERSION of the web app (run `testSmsTime` once to see how typical bank messages are read), upload this folder to Netlify.

> **v64 - secure payment processing.** (1) The admin website no longer approves anything by itself: the auto-approve and the in-browser Approve fallback are removed. Only `Code.gs` validates a request (confirmed payment, authoritative Token Price / Rupees per day, creator UID) and applies it. (2) Every payment request and QR screen (`pay_waiting`) carries `creatorUid` and is written with the creator's Firebase ID token; `database.rules.json` refuses a request whose `creatorUid` is not the writer, and refuses a `renew` unless it is written by the signed-in, non-anonymous owner of `data.uid`. Only the creator (or an admin) can change a request's `shot` / `claim` / e-mail fields or touch their QR screen. (3) `Code.gs` refuses a renewal whose `data.uid` differs from the request's `creatorUid` (not overridable), ignores request details sent in the `mail` call, and does not auto-assign a bank credit when two different creators could claim it (it is kept for manual approval). (4) A manual Approve of an unpaid / underpaid / unbound request needs a second, explicit "Approve anyway" confirmation (admin override). **Do now:** publish `database.rules.json`, re-deploy `Code.gs` as a New version (build 26), re-publish the website, and update the extension. Requests created by older extension versions have no `creatorUid`: they are never auto-applied, and a legacy RENEW cannot be approved at all - reject it and ask the customer to renew again. Anonymous sign-in must stay enabled (Create Account payments use it).

> v63: **Token balances and expiry dates are server-side only.** They live in Firebase `users/<uid>` and change ONLY (1) when `Code.gs` applies a request after a CONFIRMED payment (bank SMS matched) whose paid amount covers the requested tokens / Unlimited expiry at the CURRENT Token Price / Rupees per day (otherwise the request is held with a red note in Customer Requests and an admin can still approve it manually), (2) by an admin in the Account Center (website or extension admin panel), or (3) by the script when an admin presses Approve. A customer's request can no longer carry its own price: the amount is re-checked on the server; token counts are limited to plain numbers 0 - 1,000,000; and only the per-tab screen costs (`tokSingle1`, `tokDual1`, `tokDual2`, `tokWin`) are accepted from a request (before, any other profile field - even `tokens` / `unlimited` / `expiresAt` - could ride along in it). `database.rules.json`: a customer can no longer create a request that already contains server-owned fields (`paymentStatus`, `paidAmount`, `decidedBy` ...), and `amount` / `data.tokens` / `data.add` must be bounded numbers. The only thing a signed-in customer can still write to their own balance is a **decrease** of `tokens` / an increase of `used` (the extension spends tokens per run); a balance or an expiry can never be raised or extended from the client. **Do now:** publish `database.rules.json` (Realtime Database > Rules), re-deploy `Code.gs` as a New version, and re-publish the website.

> v62: **Live Payment Detection is now a stored, static server status.** It is kept in Firebase `live_detection = { on, state, n, at, url }`. Page refreshes and browser closings show the stored status at once - no re-check, no timer, no "older than 3 minutes = Off". It changes ONLY when the **Web App URL in Payment SMS API** is modified: the new URL is verified once (a single test request) and the verdict is stored with that URL. Re-run `setup()` once in Apps Script (it removes the old every-minute `liveDetectTick` trigger), re-publish `database.rules.json` (adds the optional `live_detection/url`), and deploy the new `Code.gs` as a New version. The extension (v6.738) follows the stored status the same way.
> v38: Delete then re-create the same Username / Gmail now works: a delete still in its Undo window is finished first, name / username entries left by deleted accounts no longer block, and a leftover login of a deleted account is removed automatically (same password). If the old password differs, delete that user once in Firebase Console > Authentication.

> v44: inside the Demo list the three labels no longer start with "Demo -": "Used Devices", "Auto Clicker Fields Limit", "Auto Clicker Settings Limit". v43: Account Center - "Demo Used Devices" is now "Demo - Used Devices" and, in the Create Account list, "Rupees per day" is now "Unlimited - Rupees per day". v42: Account Center - the Demo list boxes are now "Auto Clicker Fields Limit" and "Auto Clicker Settings Limit" (hint text "Enter Value"); Enter confirms in the Demo, Create Account and UPI Settings boxes; a Payment SMS API > Web App URL that was edited but not saved goes back to the saved URL when you close the list or open another page.
> v26: the paid-request auto-add now also runs when a tab / search shows no rows, also recognises payment_status/<id>, and retries temporary failures after 90 s. Deploy Code.gs v21 (in the outputs) as a New version.

# Setup (about 5 minutes, no server, no secrets)

## 1. Mail sender - Google Apps Script (use the ADMIN Gmail: bhoopeshbhoopesh74@gmail.com)
1. Open https://script.google.com while logged in as the admin Gmail > **New project**.
2. Delete the sample code, paste ALL of `Code.gs`. Change `DASHBOARD_URL` to your Netlify website address (e.g. https://advance-auto-clickerrr.netlify.app, no `/` at the end).
3. Choose function **test** in the toolbar > **Run**. Google asks for permission: Advanced > Go to project > Allow. A test mail must arrive in the admin inbox.
4. **Deploy > New deployment > type: Web app** > Execute as: **Me** > Who has access: **Anyone** > Deploy. Copy the **Web app URL** (ends with `/exec`).
   (After editing Code.gs later: Deploy > Manage deployments > edit > New version.)

## 2. Paste that URL in two places
* Website: open `index.html`, find `const MAIL_URL = "...";` -> replace with the URL (currently set to the deployment ending `...Gfg/exec`). Upload/redeploy the website on Netlify (it is now just this one static file; the old `cloud-functions` folder is no longer needed).
* Extension: open `auth.js`, find `const MAIL_URL = 'PASTE_APPS_SCRIPT_WEB_APP_URL_HERE';` -> same URL. Reload the extension in Chrome.
(`MAIL_KEY` is already the same in all three files.)

## 3. Firebase rules (lets the customer extension record "e-mail sent / failed")
Firebase Console > Realtime Database > Rules > paste the content of the extension's `database.rules.json` > Publish.

## 4. Website Admin Login / Account Center (matches the extension)
* **Admin Login** has the same fields as the extension: **Admin Username**, **Admin Password**, **Authenticator OTP**, **Forget Password** (Update Admin Login: old/new username + password + OTP). The sign-in is saved on the device (the next visit opens the Account Center directly); **Logout** ends it.
* **Account Center** home = **Add Account** (button at the top), **Added Accounts**, **Customer Requests**, **Demo** and **Create Account** (switch + settings drop-down), **Payment Screenshot** (Mandatory / Optional switch), plus the website's **Admin Login Extension** switch. A back arrow returns from the two lists.
* **Two-way sync with the extension (live, same Firebase paths):**
  * Demo switch, Auto Clicker Fields Limit (`maxClicks`), Auto Clicker Settings Limit (`maxSettings`) -> `demo_config/*`; Devices list -> `demo_devices`
  * Create Account switch -> `demo_config/createOn`
  * **Payment Screenshot** switch (row below Create Account; shows **Mandatory** when on, **Optional** when off) -> `demo_config/shotOn`. Off = the extension's payment pop-up lets customers send a request without uploading a screenshot; on = the screenshot is required. Changes made on the website or in the extension apply to both at once. **Publish the updated `database.rules.json`** (new `shotOn` node).
  * Rupees per day, Token Price, Clear History - Count -> `ac_sync/*` (applied to every account by the extension)
  * Requests, accounts, online / offline -> `payment_requests`, `users`, `presence`
  * **Add Account** (website) -> `users/<uid>`, `usernames/<name>`, `dupidx/*`, Firebase Authentication - the exact records the extension's Add Account writes, so the new account appears in the extension's Added Accounts list at once. Accounts added / edited / deleted in the extension appear on the website's Added Accounts list at once (both listen to `users`).
  * **Added Accounts > three dots (Edit / Delete)** - same as the extension. **Edit** opens the same "Edit User Account" form (Name, Username, Password, Mobile, Gmail, Authenticator, Tokens / Unlimited, Expiry, Tabs Limit, per-tab screen costs); changing the Gmail re-keys the login exactly like the extension, and a changed password is also updated in Firebase Authentication. **Delete** asks for confirmation, then shows **Undo (5)**; after 5 seconds the profile, username, duplicate index, Authentication login and cloud data are removed. Every change is written to the same Firebase records, so it shows in the extension's Added Accounts list at once (and the extension's edits / deletes show here at once). No change to `database.rules.json` is needed.
  * Add Account form (same as the extension): Name, Username, Password, Mobile (10 digits), Gmail, Authenticator OTP (Disabled by default; Enabled shows a setup key and asks for the 6-digit code), Tokens or Unlimited, Expiry Date (DD/MM/YYYY, required), Tabs Limit, per-tab Single / Dual Screen token costs. Name / Username must not already belong to another account.
* Rules: `database.rules.json` no longer allows `admin_config/extEnabled` (the Admin Login Extension switch was removed in v110). Delete the old `admin_config/extEnabled` value in the console once.

## How it works
* Customer sends a request -> extension saves it in Firebase and calls the mail sender -> mail with all details, the image, **Approve** / **Reject** arrives at the admin Gmail; status "sent / failed" is saved on the request and shown in the extension (Customer Requests) and on the website.
* **Approve / Reject**: the buttons in the mail open this website (`/?act=approve&req=<id>` or `act=reject`). After you confirm, the website POSTs `{ key, action: "decide", id, decision, idToken }` to the Apps Script web app (`MAIL_URL`). The script checks that the Firebase ID token belongs to an admin, claims the request, creates / renews the account, writes the status to Firebase, and sends the "Approved / Rejected" result mail. The extension and this page follow Firebase live. The Approve / Reject buttons in Customer Requests use the same call. If the script cannot be reached (or `SA_JSON` is not set yet), the website falls back to doing the same work in the browser with the admin login.
* A pending request that was never mailed is mailed when the website / extension page is opened. The mail service never sends the same request twice (except with **Resend e-mail**).
* Limit: a free Gmail can send about 100 mails per day through Apps Script.

## Device model names (Demo - Used Devices)
Browsers cannot read a laptop's model, so tap a device row (or its pencil button) and type the model, e.g. "Asus VivoBook 15". The name is saved in `device_models/<device>` and shown from then on; "Apply to all ... same hardware" names every browser of the same PC at once. **Publish the new `database.rules.json`** (new node `device_models`) in Firebase > Realtime Database > Rules.

## v10.1 - Disable / Enable accounts
Added Accounts > 3 dots > **Edit / Disable / Delete**. Disable sets `users/<uid>/disabled = true`; the extension then logs that account out at once and shows "Account Disabled" on login. Enable removes the flag. No new database rules are needed.

## v11.1 - UPI ID + request date / time
* **Account Center > UPI ID** (now titled "UPI ID & Payment Screenshot"; the Payment Screenshot Mandatory/Optional switch is inside this drop-down): the UPI ID the extension puts in the payment QR code. It starts with the extension's current ID (`bhoopeshbhoopesh74@okhdfcbank`). It is **mandatory**: a blank or invalid ID cannot be confirmed (Cancel restores the saved one). **Confirm** saves it to `demo_config/upiId`; the extension follows live, so the next QR code (and an open payment pop-up) uses the new ID at once. **Publish the new `database.rules.json`** (adds `demo_config/upiId`).
* **Customer Requests**: each request shows its date and time in the top-right corner - side by side on desktop, date on top and time below on mobile (screens up to 560 px wide).
* `Code.gs` (Apps Script): every mail now has a unique subject (`[#<request id>]`) and a unique last line (Request ID + send time) so Gmail never folds it into "Show quoted text". Paste the new `Code.gs`, then **Deploy > Manage deployments > edit > New version**.

## v12.1 - Payment SMS API (automatic "Payment successful")
1. Publish the new `database.rules.json` (nodes `sms_config`, `sms_credits`, `payment_status`, and `.indexOn` on `payment_requests`).
2. Paste the new `Code.gs` into Apps Script and **Deploy > Manage deployments > edit > New version**. `SA_JSON` must already be set (see the end of `Code.gs`).
3. The website's `MAIL_URL` (index.html) and the extension's `MAIL_URL` (auth.js) must be the SAME web app URL - the one that runs the new `Code.gs`. That URL is the endpoint.
4. Account Center > **Payment SMS API** > **Generate API Key**. Copy **URL with key**.
5. On the phone that receives the bank SMS, install an SMS-forwarder app and add a rule: POST to that URL; body = the SMS text (field `message`, JSON / form / plain text).
How it works: the SMS must contain "credited" (not "debited"); the credited amount must equal the fixed amount of a pending request (created within 2 hours of the SMS, either one first). The request then shows **PAID** on the website and the extension tells the customer "Payment successful". Approve / Reject is still done by the admin. Each SMS is used once. **Regenerate API Key** invalidates the old key at once.

### v12.2 - API key box
* The key is shown as readable text (Hide masks it) and appears the moment it is generated. After saving, the page reads `sms_config/apiKey` back; if Firebase refuses the read it says so (red message with the error code) instead of "saved". `sms_config` needs BOTH `.read` and `.write` for admins - publish `database.rules.json` under Realtime Database > Rules.

### v12.3 - end-to-end flow (SMS -> backend -> extension)
Phone SMS-forwarder --POST--> Apps Script endpoint (`?action=sms&key=...`) --verifies key, "credited", amount == the request's fixed amount--> Firebase `payment_requests/<id>/paymentStatus = successful` + public `payment_status/<id>` --live listener--> the extension's payment pop-up shows **Payment Successful**; the website shows **PAID**.
Test the endpoint from any computer: `curl -X POST "<endpoint>&key=<API key>" -d "message=Rs. 100.00 credited to a/c XX1234"` (a plain-text POST also works). Answers: `Invalid API key.` / `Ignored: ...` / `Credit ... saved; no pending request with this amount yet.` / `Payment of ... confirmed for request <id>.`


### v12.5
* **UPI Settings** is one box: open the drop-down to find the UPI ID, **Payment Notes** (default note text box + On / Off switch -> `demo_config/payNote`, `demo_config/payNoteOn`; the extension's payment pop-up and UPI payment note follow it live) and the Payment Screenshot (Mandatory / Optional) switch. Publish the updated `database.rules.json`.
* The **Firebase Rules** section was removed from the page (publish `database.rules.json` from the package in Firebase > Realtime Database > Rules - it changed: new `claim` and `shot` rules).
* Customer Requests: a request whose payment the Apps Script confirmed shows the **Payment Successful** tag + a "Payment: Payment Successful - date" line. A request where the customer only pressed Payment Completed shows **Awaiting Payment** (no e-mail yet).
* Re-deploy `Code (Apps script).gs` as a NEW VERSION (Deploy > Manage deployments > Edit > New version).

## MacroDroid Messages
* Account Center > **MacroDroid Messages** (below Customer Requests) lists every message MacroDroid sends to the Apps Script endpoint (valid API key): credited confirmations, test requests and other messages, newest first, each with its date and time. **Delete** removes one entry.
* Setup: (1) paste the new `Code.gs` into Apps Script and **redeploy** (New version); (2) publish the new `database.rules.json` (node `macrodroid_messages`).
* v10 server: every request to the endpoint is logged - POST or GET, `action=sms` in the URL or not, JSON / form / plain-text body, test actions with no text, and requests with a wrong key (shown as REJECTED, at most one per minute). Each entry stores `at` (time stamp) and `time` (IST text). Message text is read from `message`, `sms`, `text`, `body`, `content`, `msg`, `sms_message`, `notification` or `data`.
* MacroDroid: HTTP Request action, Method POST, URL = the Endpoint URL from Payment SMS API (it already contains `?action=sms&key=...`), Content-Type `application/json`, body `{"message":"{notification}"}` (or the SMS text magic text).

## v13 - MacroDroid logging fix + Messages list
**Why messages were missing:** the logging has to happen in the Apps Script (`doPost` / `doGet`), and it silently lost messages when (a) MacroDroid sent broken JSON (an SMS containing quotes / new lines makes `JSON.parse` fail), (b) the body was form / plain text, or (c) a Firebase write failed once. `MacroDroid_Logger.gs` fixes all three and can never break your other code (it never throws).

**Steps (about 3 minutes):**
1. Apps Script project > **+ > Script** > name it `MacroDroid_Logger` > paste the whole of `MacroDroid_Logger.gs`. (Needs the Script Property `SA_JSON` you already have.)
2. In your existing `Code.gs` add ONE line as the first line of each function:
   `function doPost(e) { var md = mdl_log_(e, "POST"); ...existing code... }`
   `function doGet(e)  { var md = mdl_log_(e, "GET");  ...existing code... }`
   If your old code already writes to `macrodroid_messages`, remove that old write (otherwise entries appear twice).
   Optional, after your SMS handler decides: `mdl_update_(md.id, { result: "Payment confirmed for request X", matched: true, amount: 100 });` (shows the green *Payment Successful* tag).
3. Select function **`mdl_selfTest`** > **Run**. The execution log must end with "OK". A TEST entry appears on the website - delete it with **Delete**.
4. **Deploy > Manage deployments > Edit > New version** (the `/exec` URL stays the same).
5. Firebase > Realtime Database > Rules > paste the new `database.rules.json` > Publish (adds an index on `macrodroid_messages/at`).
6. Upload the new `index.html` to Netlify.

**Troubleshooting:** run `mdl_status` in the editor - it prints the last logging error and any queued (unsent) messages. In MacroDroid use the `/exec` URL (not `/dev`), keep "follow redirects" on, and make sure the web app is deployed for "Anyone".

**Website changes (index.html):**
* MacroDroid Messages shows newest first; every entry has its exact date + time (DD/MM/YYYY and HH:MM:SS AM/PM, top-right), the message, amount, request type (POST/GET) and result, plus a **Delete** button (confirmation first).
* Tolerant reader: the time is taken from `at` (ms / seconds / text) and falls back to the time hidden in the Firebase key; plain-text entries are shown instead of dropped; only the newest 1000 entries are loaded.

## v14 - Test button + no-edit hook
* **MacroDroid Messages > Send test request** posts a test to the same endpoint MacroDroid uses and waits up to 20 s for the entry to appear in the list. "Received and stored" = the whole chain works. If it times out, the Apps Script is not logging (see below). The header line shows how many entries are stored and when the last one arrived.
* `MacroDroid_Logger.gs`: JSON test actions with no message field (or `action=test`) are now logged as **TEST** (raw body kept); and an optional wrapper `mdl_wrap_` lets you log WITHOUT editing your old code: rename `doPost` -> `doPost_main`, `doGet` -> `doGet_main`, uncomment the two wrapper functions at the bottom of the logger file. It also stores your handler's answer as the entry's Result and sets the green Payment Successful tag automatically.
* Still required (nothing on the website can do this for you): the logger must be called from `doPost` / `doGet` in the Apps Script, then **Deploy > Manage deployments > Edit > New version**.

## v15 - Code.gs now contains the MacroDroid logger (nothing to hook in by hand)
* `Code.gs` (Apps Script) is the complete file: `mdl_log_` is the FIRST statement of `doPost` and `doGet`, so every MacroDroid request is stored before anything can fail. Mailer calls of the website / extension (decide / check / mail) are skipped. A bare browser GET with no parameters (health check) is not logged.
* Each request makes ONE entry in `macrodroid_messages`; `macLog_` now completes that entry (type, result, amount, matched, reqId) instead of writing a second one. A crash while processing is written into the entry's Result.
* Do NOT add the old `MacroDroid_Logger.gs` file to the project any more (it was removed from this package).
* Steps: paste ALL of `Code.gs` over the old code (keep Script Property `SA_JSON`) > run `mdl_selfTest` (log must end with "OK") > **Deploy > Manage deployments > Edit > Version: New version > Deploy** > on the website press **Send test request**.


## Changing the Web App URL after a redeploy (no code edit)
1. Apps Script > Deploy > Manage deployments > edit > Version: New version > Deploy (or New deployment). Copy the Web App URL.
2. Website > Settings > Payment SMS API > **Apps Script Web App URL** > paste > Save.
3. Copy the new "Endpoint URL (for MacroDroid)" below it and update the MacroDroid HTTP action.
4. One-time: publish the updated `database.rules.json` in Firebase (adds `sms_config/webAppUrl`).
The `MAIL_URL` constant in `index.html` is now only a fallback. The extension's `auth.js` is separate and still needs its own URL.


## v20
* **MacroDroid Messages badge** now counts only NEW messages (arrived after the list was last opened, remembered per browser). Open the list and go back: the badge is empty.
* **UPI Settings** drop-down: UPI ID first, Payment Notes second, Payment Screenshot third.
* **Colons** added to the side headings / row labels of the Account Center (Demo:, Create Account:, Rupees per day:, Token Price:, UPI ID:, API Key: ...). The old "-" between a label and its box was removed.
* **Amount = 0 fix:** the Tokens pop-up price now follows Token Price live. The website also copies Token Price / Rupees per day to the public `demo_config/tokenPrice` and `demo_config/rupeesPerDay` (automatically, whenever they differ) so the extension's Create Account / Renew pages - which open without a login - can calculate the amount. **Publish the new `database.rules.json`** (new nodes `tokenPrice`, `rupeesPerDay`).
* **Unlimited default expiry = 1 day** (today's date; days are counted from today). Add Account: choosing Unlimited with an empty Expiry Date fills it in.
* `Code.gs` = the v13 script (new website link `https://advance-auto-clicker.netlify.app`, honest MacroDroid logging, `diagnose()`).


## v21
* **Add Account > Tokens pop-up:** Remove Token is gone (Add Token / Unlimited only). The entered tokens stay in the box after Update; type a new number to replace them or clear the box and press Update to remove them. **Edit Account keeps Remove Token.**
* If the admin website cannot copy Token Price / Rupees per day to `demo_config` (rules not published yet) it now shows a red message instead of failing silently.

## v22 - e-mail only after Submit Request + MacroDroid bank messages
* **Code.gs v14:** the request e-mail is sent ONLY when the customer presses **Submit Request** (the "Payment Completed" e-mail that used to go out when the bank SMS matched is removed; a confirmed payment only marks the request paid). A request still in the "waiting" state is refused by the mail action.
* **api-key:** the SMS endpoint accepts `api-key` (URL parameter or body field) as well as `key`. Apps Script cannot read HTTP headers.
* **Bank messages missing from the list:** every reply of the script now contains `"version"` and `"logged"`. A reply WITHOUT `logged` comes from an OLD deployment (see MacroDroid > HTTP action > response). Texts are cleaned before storing and the list can no longer be blanked by one odd entry (index.html).

* **v14 auto-match:** the script also matches a credit SMS against QR pages that are open right now (`pay_waiting`, written by extension v6.567). Publish the new `database.rules.json` (node `pay_waiting`) and redeploy `Code.gs`.

## Firebase rules (v40)
`database.rules.json` is now the SAME file as the one inside the extension package. Publish it once (Firebase > Realtime Database > Rules);
it works for both. The admin login / Forgot Password look the username up through a short anonymous session, so
Firebase > Authentication > Sign-in method > **Anonymous** must be enabled (it already is if the extension login works).


## v32 - Extension "Live Payment Detection" pre-check (Code.gs build 22)
* New mailer action `mdtest` (needs MAIL_KEY): the extension's QR payment page calls it before it turns Live Payment Detection on. The script writes a test entry (`type: test`, `source: extension`) into `macrodroid_messages`, READS IT BACK from that node and answers `verified: true` only if it matched. The extension shows "Live Payment Detection is On" (green) only for that answer, otherwise "... is Off" (red).
* The test entry is deleted again right after it was verified, so the MacroDroid Messages list is not filled with checks. To keep them visible set `var MD_CHECK_KEEP = true;` in Code.gs.
* Setup: paste the new `Code.gs` into Apps Script and **Deploy > Manage deployments > Edit > New version**. No change to `database.rules.json` is needed.
* Note: this proves the chain extension > Apps Script > Firebase > MacroDroid Messages (the same chain the website's "Send test request" button checks). It cannot prove that the MacroDroid app on the phone is running.


## v33 - continuous Live Payment Detection poll (Code.gs build 23)
* The extension now repeats the `mdtest` check back-to-back while a QR page is open. `doPost` answers it before taking the script lock, so polling never delays a bank SMS. Redeploy as a New version. Note: constant polling makes about 3 Firebase calls per check from the script; many customers on the QR page at once raise Apps Script daily quota use accordingly.


## v34 / website v47 - Live Payment Detection indicator + continuous verification
* **Website > MacroDroid Messages:** right after "Messages :" a status shows a green dot + "Live Payment Detection is On" or a red dot + "Live Payment Detection is Off" (Off until the first check passes).
* **How it is verified (real time):** while the admin page is signed in it sends a test request to the Apps Script endpoint (`mdtest`, kept), then waits until that entry really appears in this MacroDroid Messages list (the live `macrodroid_messages` listener). Seen within 15 s = On. The next check starts immediately after the previous one (1 s pause only after a failure). The entry is removed again and never listed / counted.
* **Extension link:** after every check the website writes `live_detection = { on, n, at }`; the extension listens to it live. If the page closes or loses its connection, Firebase writes `on:false` at once (onDisconnect).
* **Setup (all three are required):** (1) paste the new `Code.gs` and Deploy > New version; (2) Firebase > Realtime Database > Rules > paste the new `database.rules.json` > Publish (adds `live_detection`); (3) keep the admin website open - it is the verifier.

## website v48 - Live Payment Detection check now uses the same route as MacroDroid
* The check posts to the Apps Script SMS endpoint with the API key (identical to "Send test request" and to MacroDroid) and confirms the entry in the live MacroDroid Messages list. It no longer needs the `mdtest` script action, so **no Code.gs redeploy is needed** for it (the Payment SMS API key must exist). Check entries are removed again ~8 s after they were seen and are never listed or counted as messages.
* Still required: publish `database.rules.json` (node `live_detection`) so the extension can follow the status.


## website v56 - Delete all = the open option only
- "Delete all" counts and deletes only the history of the option that is open (MacroDroid Messages, Test Messages or Other Messages); the other two options are left untouched. The pop-up shows just that option's count and no version number.

## website v54 - Delete all clears all 3 options
- The Delete all pop-up now lists the three counts (MacroDroid Messages / Test Messages / Other Messages and the total) and deletes every stored message of all three options at once, whichever option or search is shown. The result is re-checked and a second pass removes anything left.

## website v53 - Other Messages, working search, Delete all = every option
- A third option "Other Messages" (right of Test Messages) lists every message that is neither a confirmed MacroDroid payment nor a test request (other / rejected / unconfirmed credit).
- The search box now matches everything shown on the cards (name, amount, result, raw body, date / time, type); several words must all match.
- "Delete all" removes the messages of ALL three options at once, whichever option or search is active.

## website v52 - MacroDroid Messages / Test Messages tabs
- Below the search box (MacroDroid Messages page) two options sit side by side: "MacroDroid Messages" (default) and "Test Messages". The page always opens on MacroDroid Messages, also when you leave it and come back.
- "Test Messages" lists the history of test requests (with the Send test request button's results); the automatic live-check pings are not listed.

## website v51 - stable "Checking..." transitions
- A change of the Apps Script Web App URL or the API key (Payment SMS API) now starts a new verification at once: a stable yellow "Checking..." (three-dot animation) is shown and published, and stays until that check's verdict, which then replaces it in place with "Live Payment Detection is On" (green) or "Off" (red).
- Checking is shown for at least 0.6 s, results of older / aborted checks are ignored, an unchanged state is never re-drawn, and after an Off verdict the background re-checks run silently (no flicker back to Checking).
- Extension v6.731 receives every change instantly through its background listener.

## website v50 - "Checking..." status next to Messages
- MacroDroid Messages > "Messages :" now shows a yellow "Checking..." (animated three dots) while a test request is being verified, then a green dot + "Live Payment Detection is On" or a red dot + "Live Payment Detection is Off" the instant the result is known.
- The same state is written to `live_detection = { on, state, n, at }` after every change and mirrored beneath the QR code in the extension (v6.730).
- Publish the updated `database.rules.json` (the `state` field is validated as checking / on / off).

## website v49 - faster, server-time status
* Every status written to `live_detection` now carries Firebase server time (`at`), so the extension shows it immediately. "Off" is published after 10 s without proof (was 15 s) and the pause after a failed check is 0.5 s. If the status cannot be written (rules not published), hover the indicator: its tooltip says so.


## website v57 / Code.gs v35
* **Live Payment Detection now runs on the server.** Paste the new `Code.gs`, Deploy > New version, then run `setup()` ONCE (installs the every-minute `liveDetectTick` trigger). The website and the extension only listen to `live_detection`; closing the website no longer switches it off (a status older than 3 minutes shows Off).
* History keeps only **MacroDroid Messages** and **Test Messages**. "Other Messages" is gone; rejected/other entries are not stored (stray ones are removed). The "stored - last received" line is removed; both tabs are 50/50.
* Publish `database.rules.json` is unchanged.


## v111 - Authenticator OTP on the extension Login page + Edit dialog alignment
- **Publish `database_rules.hardened.json` again** (Realtime Database > Rules). New: `usernames/<name>/o` (boolean, true = Authenticator OTP on; a non-admin can only set the value that matches `users/<uid>/otpOn`) and the account itself may read `admin_vault/<uid>/authenticatorKey` (nothing else in the vault). The same file is in the Main Extension ZIP v7.3.9 - install both together.
- Add / Edit Account now writes the `o` flag into the username index. Accounts that already had the Authenticator enabled get it automatically the first time an admin opens Added Accounts.
- Edit User Account on a phone: labels that wrap to two lines ("Unlimited Tokens Expiry Date:") no longer push their box lower than the neighbouring box; both boxes of a row now line up.


## v112
- Edit / Add Account dialog: every left/right pair of boxes (Authenticator OTP + OTP, Unlimited Access + Expiry, Tokens + Expiry, Tabs Token + Tabs Limit) now shares grid rows, so both boxes always have the same top, height and width on phones. The three Screen boxes use the same height too.
- `database_rules.hardened.json` is the same file as in the extension and the Dashboard.
